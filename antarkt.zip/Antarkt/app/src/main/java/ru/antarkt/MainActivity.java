package ru.antarkt;
import android.app.Activity;import android.graphics.Color;import android.os.Bundle;import android.webkit.*;
public class MainActivity extends Activity {
    WebView w;
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);
        w = new WebView(this);w.setBackgroundColor(Color.BLACK);setContentView(w);
        WebSettings s = w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);
        w.addJavascriptInterface(new Object() {
            @JavascriptInterface public void save(String j) {
                getSharedPreferences("a", 0).edit().putString("data", j).apply();
                AntarktWidget.refresh(MainActivity.this);
            }
        }, "Android");
        w.setWebViewClient(new WebViewClient());
        w.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() { if (w.canGoBack()) w.goBack(); else super.onBackPressed(); }
}
