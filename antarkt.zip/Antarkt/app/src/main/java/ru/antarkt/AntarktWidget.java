package ru.antarkt;
import android.app.*;import android.appwidget.*;import android.content.*;import android.content.res.ColorStateList;
import android.os.*;import android.util.TypedValue;import android.view.View;import android.widget.RemoteViews;
import org.json.*;import java.text.SimpleDateFormat;import java.util.*;
public class AntarktWidget extends AppWidgetProvider {
    static final String ACT = "ru.antarkt.TICK";
    static final int[] LI = {R.id.l0,R.id.l1,R.id.l2,R.id.l3,R.id.l4,R.id.l5,R.id.l6,R.id.l7};
    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { refresh(c); }
    @Override public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle o) { refresh(c); }
    @Override public void onReceive(Context c, Intent i) { super.onReceive(c, i); if (ACT.equals(i.getAction()) || Intent.ACTION_TIME_CHANGED.equals(i.getAction()) || "android.intent.action.TIME_SET".equals(i.getAction())) refresh(c); }
    static int sec(String t) { try { String[] a = t.split(":"); return Integer.parseInt(a[0].trim()) * 3600 + Integer.parseInt(a[1].trim()) * 60; } catch (Exception x) { return 0; } }
    static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        long nx = Long.MAX_VALUE;
        for (int id : m.getAppWidgetIds(new ComponentName(c, AntarktWidget.class))) nx = Math.min(nx, upd(c, m, id));
        if (nx == Long.MAX_VALUE) return;
        PendingIntent pi = PendingIntent.getBroadcast(c, 0, new Intent(c, AntarktWidget.class).setAction(ACT), PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC, nx, pi);
        else am.setAndAllowWhileIdle(AlarmManager.RTC, nx, pi);
    }
    static void put(RemoteViews v, int id, String t, int col, float sp) { v.setTextViewText(id, t); v.setTextColor(id, col); v.setTextViewTextSize(id, TypedValue.COMPLEX_UNIT_SP, sp); }
    static long upd(Context c, AppWidgetManager m, int id) {
        SharedPreferences p = c.getSharedPreferences("a", 0), w = c.getSharedPreferences("w" + id, 0);
        int bg = (w.getInt("bga", 200) << 24) | (w.getInt("bgc", 0x000000) & 0xFFFFFF), tx = 0xFF000000 | w.getInt("tx", 0xFFFFFF), ac = 0xFF000000 | w.getInt("ac", 0x4C8DFF);
        int dim = (tx & 0xFFFFFF) | 0xA0000000, n = w.getInt("n", 4);
        float sc = w.getInt("sz", 100) / 100f;
        boolean sn = w.getBoolean("nx", true), sr = w.getBoolean("rm", false);
        String want = w.getString("cls", "");
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
        Bundle op = m.getAppWidgetOptions(id); int hh = op.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110), ww = op.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250); boolean micro = ww < 120; float sc0 = sc;
        boolean tiny = hh < 75, mid = hh < 115; sc = sc * (tiny ? 0.62f : mid ? 0.82f : 1f);
        String cname = "Антаркт"; List<String[]> L = new ArrayList<>();
        Calendar cal = Calendar.getInstance(); int dow = cal.get(Calendar.DAY_OF_WEEK) - 1;
        try {
            JSONObject d = new JSONObject(p.getString("data", "{}")); JSONArray ls = d.getJSONArray("list");
            JSONObject sch = ls.getJSONObject(0); String cur = want.isEmpty() ? d.optString("cur") : want;
            for (int i = 0; i < ls.length(); i++) if (ls.getJSONObject(i).optString("id").equals(cur)) sch = ls.getJSONObject(i);
            cname = sch.optString("name");
            JSONArray da = sch.getJSONObject("d").optJSONArray("" + dow);
            if (da != null) for (int i = 0; i < da.length(); i++) {
                JSONObject o = da.getJSONObject(i); String s = o.optString("s"), e = o.optString("e");
                if (s.contains(":") && e.contains(":") && sec(e) > sec(s)) L.add(new String[]{o.optString("n", "Пара"), o.optString("r"), s, e});
            }
        } catch (Exception x) {}
        Collections.sort(L, (a, b) -> sec(a[2]) - sec(b[2]));
        double now = cal.get(Calendar.HOUR_OF_DAY) * 3600 + cal.get(Calendar.MINUTE) * 60 + cal.get(Calendar.SECOND) + cal.get(Calendar.MILLISECOND) / 1000.0;
        Calendar z = (Calendar) cal.clone(); z.set(Calendar.HOUR_OF_DAY, 0); z.set(Calendar.MINUTE, 0); z.set(Calendar.SECOND, 0); z.set(Calendar.MILLISECOND, 0);
        long d0 = z.getTimeInMillis();
        String[] cu = null, nx = null, pv = null;
        for (String[] l : L) { if (sec(l[3]) <= now) pv = l; else if (sec(l[2]) <= now) cu = l; else if (nx == null) nx = l; }
        String st, nm = "", mt = ""; double target = -1, pg = 0;
        if (cu != null) { st = "УРОК"; nm = cu[0]; target = sec(cu[3]); pg = (now - sec(cu[2])) / (sec(cu[3]) - sec(cu[2])); mt = cu[2] + "–" + cu[3] + (sr && !cu[1].isEmpty() ? " · " + cu[1] : ""); }
        else if (nx != null) { nm = nx[0]; target = sec(nx[2]); mt = nx[2] + "–" + nx[3] + (sr && !nx[1].isEmpty() ? " · " + nx[1] : "");
            if (pv != null) { st = "ПЕРЕМЕНА"; pg = (now - sec(pv[3])) / (sec(nx[2]) - sec(pv[3])); } else st = "ДО НАЧАЛА"; }
        else { st = L.isEmpty() ? "НЕТ УРОКОВ" : "УРОКИ ЗАКОНЧИЛИСЬ"; nm = L.isEmpty() ? "Отдыхаем" : "Свобода"; }
        v.setInt(R.id.bg, "setColorFilter", 0xFF000000 | (bg & 0xFFFFFF)); v.setInt(R.id.bg, "setImageAlpha", bg >>> 24);
        put(v, R.id.hd, cname + " · " + new SimpleDateFormat("EE, d MMM", new Locale("ru")).format(cal.getTime()), dim, 12 * sc);
        put(v, R.id.st, st, ac, 11 * sc); put(v, R.id.nm, tiny && cu == null && nx != null ? "Перемена · " + nm : nm, tx, 20 * sc); put(v, R.id.mt, mt, dim, 13 * sc);
        v.setViewVisibility(R.id.hd, mid ? View.GONE : View.VISIBLE); v.setViewVisibility(R.id.st, tiny ? View.GONE : View.VISIBLE);
        v.setViewVisibility(R.id.mt, hh >= 105 && !mt.isEmpty() ? View.VISIBLE : View.GONE);
        int cap = hh < 150 ? 0 : Math.min(n, Math.max(0, (hh - 135) / 19));
        if (target >= 0) {
            v.setViewVisibility(R.id.cd, View.VISIBLE); v.setViewVisibility(R.id.pb, View.VISIBLE);
            v.setChronometerCountDown(R.id.cd, true);
            v.setChronometer(R.id.cd, SystemClock.elapsedRealtime() + (long) ((target - now) * 1000), null, true);
            v.setTextColor(R.id.cd, tx); v.setTextViewTextSize(R.id.cd, TypedValue.COMPLEX_UNIT_SP, 38 * sc);
            v.setProgressBar(R.id.pb, 1000, (int) (Math.max(0, Math.min(1, pg)) * 1000), false);
            if (Build.VERSION.SDK_INT >= 31) v.setColorStateList(R.id.pb, "setProgressTintList", ColorStateList.valueOf(ac));
        } else { v.setViewVisibility(R.id.cd, View.GONE); v.setViewVisibility(R.id.pb, View.GONE); }
        boolean solo = micro && target >= 0; float dn = c.getResources().getDisplayMetrics().density;
        v.setViewVisibility(R.id.sp1, solo ? View.VISIBLE : View.GONE); v.setViewVisibility(R.id.sp2, solo ? View.VISIBLE : View.GONE); v.setViewVisibility(R.id.col, solo ? View.GONE : View.VISIBLE);
        v.setViewPadding(R.id.inner, (int) ((micro || tiny ? 6 : 12) * dn), (int) ((micro || tiny ? 2 : 6) * dn), (int) ((micro || tiny ? 6 : 12) * dn), (int) ((micro || tiny ? 2 : 6) * dn));
        if (micro) { v.setViewVisibility(R.id.hd, View.GONE); v.setViewVisibility(R.id.st, View.GONE); v.setViewVisibility(R.id.mt, View.GONE);
            v.setViewVisibility(R.id.pb, hh >= 44 && target >= 0 ? View.VISIBLE : View.GONE);
            if (target >= 0) v.setTextViewTextSize(R.id.cd, TypedValue.COMPLEX_UNIT_SP, Math.max(9f, Math.min(Math.min(38f * sc0, (ww - 8) / (target - now >= 3600 ? 4.9f : 3.5f)), (hh - 8) / 1.4f)));
            else v.setTextViewTextSize(R.id.nm, TypedValue.COMPLEX_UNIT_SP, Math.max(9f, Math.min(14f, ww / 6f))); }
        if (sn && cu != null && nx != null && hh >= 130) { put(v, R.id.nx, "Дальше: " + nx[0] + " · " + nx[2], dim, 13 * sc); v.setViewVisibility(R.id.nx, View.VISIBLE); }
        else v.setViewVisibility(R.id.nx, View.GONE);
        int k = 0;
        for (String[] l : L) { if (sec(l[3]) <= now) continue; if (k >= cap || k >= 8) break;
            put(v, LI[k], l[2] + "  " + l[0] + (sr && !l[1].isEmpty() ? " · " + l[1] : ""), l == cu ? ac : tx, 13 * sc); v.setViewVisibility(LI[k], View.VISIBLE); k++; }
        for (; k < 8; k++) v.setViewVisibility(LI[k], View.GONE);
        v.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE));
        m.updateAppWidget(id, v);
        return target >= 0 ? d0 + (long) (target * 1000) + 300 : d0 + 86400000L + 60000;
    }
}
