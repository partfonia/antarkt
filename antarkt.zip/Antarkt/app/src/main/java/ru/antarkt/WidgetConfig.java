package ru.antarkt;
import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.*;
import org.json.*;
import java.util.*;

public class WidgetConfig extends Activity {
    static final int BG = 0xFF0B0B0E, CARD = 0xFF15151A, LINE = 0xFF2A2A31, MUTE = 0xFF8A8A92, ACC0 = 0xFF4C8DFF;
    static final int[] PAL = {0x000000, 0x1C1C22, 0x0E1F3D, 0xFFFFFF, 0x4C8DFF, 0x3DD68C, 0xFF7A59, 0xFFC83D, 0xB07CFF, 0xFF5C8A};
    int id, alpha, sz, n, cardIdx = 0; boolean nxt, rm; String cls = "";
    int[] cv = new int[3]; View[][] dots = new View[3][PAL.length]; EditText[] hx = new EditText[3]; boolean lock;
    SharedPreferences w; LinearLayout col, pv; TextView pHd, pSt, pNm, pCd; SeekBar aBar;
    List<TextView> chips = new ArrayList<>(); List<String> ids = new ArrayList<>();

    int dp(float x) { return (int) (x * getResources().getDisplayMetrics().density + .5f); }
    GradientDrawable rr(int color, float r, int stroke) { GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(r)); if (stroke != 0) g.setStroke(dp(1), stroke); return g; }
    TextView tv(String t, float sp, int color, boolean bold) { TextView v = new TextView(this); v.setText(t); v.setTextSize(sp); v.setTextColor(color); if (bold) v.setTypeface(Typeface.DEFAULT_BOLD); return v; }
    void tap(View v) { v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); }
    String hex(int c) { return String.format("#%06X", c & 0xFFFFFF); }

    LinearLayout card(String title) {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(rr(CARD, 22, LINE)); c.setPadding(dp(16), dp(14), dp(16), dp(16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = dp(12); col.addView(c, lp);
        if (title != null) { TextView t = tv(title.toUpperCase(), 11, MUTE, true); t.setLetterSpacing(.12f); t.setPadding(0, 0, 0, dp(10)); c.addView(t); }
        c.setAlpha(0); c.setTranslationY(dp(26));
        c.animate().alpha(1).translationY(0).setStartDelay(cardIdx++ * 70L).setDuration(400).setInterpolator(new DecelerateInterpolator()).start();
        return c;
    }
    void upd() {
        pv.setBackground(rr((alpha << 24) | cv[0], 18, 0));
        pHd.setTextColor(0xA0000000 | cv[1]); pSt.setTextColor(0xFF000000 | cv[2]); pNm.setTextColor(0xFF000000 | cv[1]); pCd.setTextColor(0xFF000000 | cv[1]);
        float k = sz / 100f; pHd.setTextSize(11 * k); pSt.setTextSize(10 * k); pNm.setTextSize(17 * k); pCd.setTextSize(30 * k);
    }
    void mark(int key) {
        for (int i = 0; i < PAL.length; i++) {
            boolean on = PAL[i] == cv[key];
            GradientDrawable g = new GradientDrawable(); g.setShape(GradientDrawable.OVAL); g.setColor(0xFF000000 | PAL[i]); g.setStroke(dp(on ? 3 : 1), on ? 0xFFFFFFFF : LINE);
            dots[key][i].setBackground(g); dots[key][i].animate().scaleX(on ? 1.15f : 1f).scaleY(on ? 1.15f : 1f).setDuration(160).start();
        }
    }
    void setColor(int key, int c) { cv[key] = c & 0xFFFFFF; lock = true; hx[key].setText(hex(cv[key])); lock = false; mark(key); upd(); }
    void colorRow(LinearLayout c, String label, int key) {
        TextView l = tv(label, 14, 0xFFFFFFFF, true); l.setPadding(0, dp(key == 0 ? 0 : 14), 0, dp(8)); c.addView(l);
        HorizontalScrollView hs = new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(4), dp(4), dp(4), dp(4)); hs.addView(row); c.addView(hs);
        for (int i = 0; i < PAL.length; i++) {
            final int p = PAL[i]; View d = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34)); lp.rightMargin = dp(10); row.addView(d, lp); dots[key][i] = d;
            d.setOnClickListener(x -> { tap(x); setColor(key, p); });
        }
        EditText e = new EditText(this); hx[key] = e; e.setText(hex(cv[key])); e.setTextSize(14); e.setTextColor(0xFFFFFFFF); e.setSingleLine(true);
        e.setBackground(rr(0xFF1E1E24, 12, LINE)); e.setPadding(dp(12), dp(6), dp(12), dp(6)); row.addView(e, new LinearLayout.LayoutParams(dp(96), dp(40)));
        e.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c2) {}
            public void onTextChanged(CharSequence s, int a, int b, int c2) {}
            public void afterTextChanged(Editable s) { if (lock) return; try { cv[key] = Color.parseColor(s.toString().trim()) & 0xFFFFFF; mark(key); upd(); } catch (Exception ex) {} }
        });
        mark(key);
    }
    SeekBar slider(LinearLayout c, String label, int max, int val, java.util.function.IntFunction<String> f, java.util.function.IntConsumer on) {
        LinearLayout h = new LinearLayout(this); h.setPadding(0, dp(10), 0, 0);
        TextView a = tv(label, 14, 0xFFFFFFFF, true), b = tv(f.apply(val), 14, MUTE, false);
        h.addView(a, new LinearLayout.LayoutParams(0, -2, 1)); h.addView(b); c.addView(h);
        SeekBar s = new SeekBar(this); s.setMax(max); s.setProgress(val);
        s.setProgressTintList(ColorStateList.valueOf(ACC0)); s.setThumbTintList(ColorStateList.valueOf(0xFFFFFFFF)); c.addView(s);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar sb, int p, boolean u) { b.setText(f.apply(p)); on.accept(p); upd(); }
            public void onStartTrackingTouch(SeekBar sb) {}
            public void onStopTrackingTouch(SeekBar sb) { tap(sb); }
        });
        return s;
    }
    Switch sw(LinearLayout c, String t, boolean on, java.util.function.Consumer<Boolean> f) {
        Switch s = new Switch(this); s.setText(t); s.setTextSize(15); s.setTextColor(0xFFFFFFFF); s.setChecked(on); s.setPadding(0, dp(8), 0, dp(8));
        s.setThumbTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}}, new int[]{ACC0, 0xFFCCCCCC}));
        s.setTrackTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}}, new int[]{0x884C8DFF, 0x33FFFFFF}));
        s.setOnCheckedChangeListener((b, v) -> { tap(b); f.accept(v); }); c.addView(s); return s;
    }
    TextView chip(LinearLayout row, String t) {
        TextView c = tv(t, 14, 0xFFFFFFFF, true); c.setPadding(dp(16), dp(9), dp(16), dp(9)); c.setBackground(rr(0xFF1E1E24, 20, LINE));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dp(8); row.addView(c, lp); return c;
    }
    void preset(int bg, int tx, int ac, int a) {
        if (bg >= 0) setColor(0, bg); if (tx >= 0) setColor(1, tx); if (ac >= 0) setColor(2, ac); aBar.setProgress(a);
    }
    void markCls() { for (int i = 0; i < chips.size(); i++) { boolean on = ids.get(i).equals(cls); chips.get(i).setBackground(rr(on ? 0xFF4C8DFF : 0xFF1E1E24, 20, on ? 0xFF4C8DFF : LINE)); } }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b); setResult(RESULT_CANCELED);
        id = getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, 0); if (id == 0) { finish(); return; }
        getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        w = getSharedPreferences("w" + id, 0);
        cv[0] = w.getInt("bgc", 0) & 0xFFFFFF; cv[1] = w.getInt("tx", 0xFFFFFF) & 0xFFFFFF; cv[2] = w.getInt("ac", 0x4C8DFF) & 0xFFFFFF;
        alpha = w.getInt("bga", 200); sz = w.getInt("sz", 100); n = w.getInt("n", 4); nxt = w.getBoolean("nx", true); rm = w.getBoolean("rm", false); cls = w.getString("cls", "");
        FrameLayout root = new FrameLayout(this); root.setBackgroundColor(BG);
        ScrollView sv = new ScrollView(this); sv.setClipToPadding(false); sv.setPadding(dp(18), dp(40), dp(18), dp(110)); sv.setVerticalScrollBarEnabled(false);
        col = new LinearLayout(this); col.setOrientation(LinearLayout.VERTICAL); sv.addView(col); root.addView(sv);
        col.addView(tv("Виджет", 32, 0xFFFFFFFF, true));
        TextView sub = tv("Настройте под себя. Предпросмотр меняется сразу", 14, MUTE, false); sub.setPadding(0, dp(4), 0, dp(6)); col.addView(sub);

        LinearLayout pc = card(null); pc.setPadding(dp(10), dp(10), dp(10), dp(10));
        FrameLayout box = new FrameLayout(this);
        box.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF22385E, 0xFF0A0F1E, 0xFF1F3B38}));
        pv = new LinearLayout(this); pv.setOrientation(LinearLayout.VERTICAL); pv.setPadding(dp(14), dp(10), dp(14), dp(10));
        pHd = tv("8Б · пт, 13 нояб.", 11, 0xFFFFFFFF, false); pv.addView(pHd);
        LinearLayout r = new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); LinearLayout cl = new LinearLayout(this); cl.setOrientation(LinearLayout.VERTICAL);
        pSt = tv("УРОК", 10, 0xFFFFFFFF, true); pNm = tv("Алгебра", 17, 0xFFFFFFFF, true); cl.addView(pSt); cl.addView(pNm);
        pCd = tv("24:18", 30, 0xFFFFFFFF, true); r.addView(cl, new LinearLayout.LayoutParams(0, -2, 1)); r.addView(pCd); pv.addView(r);
        FrameLayout.LayoutParams fl = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER); fl.setMargins(dp(14), dp(18), dp(14), dp(18)); box.addView(pv, fl);
        pc.addView(box, new LinearLayout.LayoutParams(-1, dp(130)));

        LinearLayout c1 = card("Класс"); HorizontalScrollView hs = new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false);
        LinearLayout cr = new LinearLayout(this); hs.addView(cr); c1.addView(hs);
        List<String> names = new ArrayList<>(); names.add("Из приложения"); ids.add("");
        try { JSONArray ls = new JSONObject(getSharedPreferences("a", 0).getString("data", "{}")).getJSONArray("list");
            for (int i = 0; i < ls.length(); i++) { names.add(ls.getJSONObject(i).optString("name")); ids.add(ls.getJSONObject(i).optString("id")); } } catch (Exception x) {}
        for (int i = 0; i < names.size(); i++) { final String cid = ids.get(i); TextView t = chip(cr, names.get(i)); chips.add(t); t.setOnClickListener(x -> { tap(x); cls = cid; markCls(); }); }
        markCls();

        LinearLayout c2 = card("Цвета"); colorRow(c2, "Фон", 0); colorRow(c2, "Текст", 1); colorRow(c2, "Акцент", 2);

        LinearLayout c3 = card("Фон и размер");
        aBar = slider(c3, "Прозрачность фона", 255, alpha, p -> (100 - p * 100 / 255) + "%", p -> alpha = p);
        slider(c3, "Размер текста", 100, sz - 60, p -> (p + 60) + "%", p -> sz = p + 60);
        slider(c3, "Уроков в списке", 8, n, p -> String.valueOf(p), p -> n = p);

        LinearLayout c4 = card("Быстрые стили"); HorizontalScrollView hp = new HorizontalScrollView(this); hp.setHorizontalScrollBarEnabled(false);
        LinearLayout pr = new LinearLayout(this); hp.addView(pr); c4.addView(hp);
        chip(pr, "Стекло").setOnClickListener(x -> { tap(x); preset(0x000000, 0xFFFFFF, 0x4C8DFF, 90); });
        chip(pr, "Прозрачный").setOnClickListener(x -> { tap(x); preset(-1, -1, -1, 0); });
        chip(pr, "Тёмный").setOnClickListener(x -> { tap(x); preset(0x1C1C22, 0xFFFFFF, 0x3DD68C, 225); });
        chip(pr, "Светлый").setOnClickListener(x -> { tap(x); preset(0xFFFFFF, 0x000000, 0x4C8DFF, 235); });

        LinearLayout c5 = card("Показывать"); sw(c5, "Следующий урок", nxt, v -> nxt = v); sw(c5, "Кабинеты", rm, v -> rm = v);

        Button ok = new Button(this); ok.setText("Готово"); ok.setAllCaps(false); ok.setTextSize(17); ok.setTypeface(Typeface.DEFAULT_BOLD); ok.setTextColor(0xFFFFFFFF);
        ok.setBackground(rr(ACC0, 28, 0)); ok.setStateListAnimator(null);
        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(-1, dp(56), Gravity.BOTTOM); bl.setMargins(dp(18), 0, dp(18), dp(22)); root.addView(ok, bl);
        ok.setOnClickListener(x -> {
            tap(x);
            w.edit().putInt("bgc", cv[0]).putInt("tx", cv[1]).putInt("ac", cv[2]).putInt("bga", alpha).putInt("sz", sz).putInt("n", n)
                .putBoolean("nx", nxt).putBoolean("rm", rm).putString("cls", cls).apply();
            AntarktWidget.refresh(this);
            setResult(RESULT_OK, new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)); finish();
        });
        setContentView(root); upd();
    }
}
