package ru.antarkt;
import android.app.Activity;import android.appwidget.AppWidgetManager;import android.content.*;import android.graphics.Color;
import android.os.Bundle;import android.view.View;import android.widget.*;import org.json.*;import java.util.*;
public class WidgetConfig extends Activity {
    int id; SharedPreferences w; LinearLayout r;
    Map<String, EditText> hex = new HashMap<>(); List<String> ids = new ArrayList<>();
    int dp(int x) { return (int) (x * getResources().getDisplayMetrics().density); }
    TextView lab(String t) { TextView v = new TextView(this); v.setText(t); v.setPadding(0, dp(14), 0, dp(4)); r.addView(v); return v; }
    SeekBar bar(String t, int max, int val) { lab(t); SeekBar s = new SeekBar(this); s.setMax(max); s.setProgress(val); r.addView(s); return s; }
    Switch sw(String t, boolean on) { Switch s = new Switch(this); s.setText(t); s.setChecked(on); s.setPadding(0, dp(10), 0, dp(10)); r.addView(s); return s; }
    void colors(String t, String key, int def, int[] cs) {
        lab(t); LinearLayout h = new LinearLayout(this);
        EditText e = new EditText(this); e.setHint("#RRGGBB"); e.setText(String.format("#%06X", w.getInt(key, def) & 0xFFFFFF)); hex.put(key, e);
        for (int c : cs) { Button b = new Button(this); b.setBackgroundColor(0xFF000000 | c); b.setLayoutParams(new LinearLayout.LayoutParams(0, dp(40), 1));
            b.setOnClickListener(x -> e.setText(String.format("#%06X", c))); h.addView(b); }
        r.addView(h); r.addView(e);
    }
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b); setResult(RESULT_CANCELED);
        id = getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, 0); if (id == 0) { finish(); return; }
        w = getSharedPreferences("w" + id, 0);
        r = new LinearLayout(this); r.setOrientation(LinearLayout.VERTICAL); r.setPadding(dp(18), dp(18), dp(18), dp(30));
        ScrollView sv = new ScrollView(this); sv.addView(r); setContentView(sv);
        lab("Класс"); List<String> names = new ArrayList<>(); names.add("Текущий в приложении"); ids.add("");
        try { JSONArray ls = new JSONObject(getSharedPreferences("a", 0).getString("data", "{}")).getJSONArray("list");
            for (int i = 0; i < ls.length(); i++) { names.add(ls.getJSONObject(i).optString("name")); ids.add(ls.getJSONObject(i).optString("id")); } } catch (Exception x) {}
        Spinner sp = new Spinner(this); sp.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names));
        sp.setSelection(Math.max(0, ids.indexOf(w.getString("cls", "")))); r.addView(sp);
        int[] pal = {0x000000, 0x1C1C22, 0x0E1F3D, 0xFFFFFF, 0x4C8DFF, 0x3DD68C, 0xFF7A59, 0xFFC83D};
        colors("Цвет фона", "bgc", 0x000000, pal); colors("Цвет текста", "tx", 0xFFFFFF, pal); colors("Цвет акцента", "ac", 0x4C8DFF, pal);
        SeekBar a = bar("Прозрачность фона", 255, w.getInt("bga", 200));
        SeekBar z = bar("Размер текста (60–160%)", 100, w.getInt("sz", 100) - 60);
        SeekBar n = bar("Уроков в списке (0–8)", 8, w.getInt("n", 4));
        Switch nx = sw("Показывать «Дальше»", w.getBoolean("nx", true)), rm = sw("Показывать кабинеты", w.getBoolean("rm", false));
        Button ok = new Button(this); ok.setText("Готово"); r.addView(ok);
        ok.setOnClickListener(x -> {
            SharedPreferences.Editor e = w.edit();
            for (String k : hex.keySet()) try { e.putInt(k, Color.parseColor(hex.get(k).getText().toString().trim()) & 0xFFFFFF); } catch (Exception ex) {}
            e.putString("cls", ids.get(sp.getSelectedItemPosition())).putInt("bga", a.getProgress()).putInt("sz", z.getProgress() + 60).putInt("n", n.getProgress())
             .putBoolean("nx", nx.isChecked()).putBoolean("rm", rm.isChecked()).apply();
            AntarktWidget.refresh(this);
            setResult(RESULT_OK, new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)); finish();
        });
    }
}
