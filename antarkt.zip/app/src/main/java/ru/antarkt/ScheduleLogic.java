package ru.antarkt;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Правила расписания для виджета и уведомлений. Повторяет assets/logic.js —
 * при изменении правил меняйте оба файла. Оба проверяются одинаковыми тестами
 * (tests/logic.test.js и tests/java/ScheduleLogicTest.java).
 *
 * Здесь нет Android-классов: только java.util, чтобы тесты шли на обычной JVM.
 */
final class ScheduleLogic {

    /** Насколько далеко ищем следующий урок (летние каникулы ~ 3 месяца). */
    static final int SEARCH_DAYS = 400;

    private ScheduleLogic() {
    }

    // ---------------------------------------------------------------- время и даты

    /** "08:30" → секунды от полуночи; -1, если строка не похожа на время. */
    static int sec(String s) {
        if (s == null) return -1;
        s = s.trim();
        int colon = s.indexOf(':');
        if (colon < 1 || colon > 2 || s.length() != colon + 3) return -1;
        try {
            int h = Integer.parseInt(s.substring(0, colon));
            int m = Integer.parseInt(s.substring(colon + 1));
            if (h < 0 || h > 23 || m < 0 || m > 59) return -1;
            return h * 3600 + m * 60;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    static String hm(int seconds) {
        int x = ((seconds % 86400) + 86400) % 86400;
        return String.format(Locale.US, "%02d:%02d", x / 3600, (x % 3600) / 60);
    }

    /** Дата → "2026-11-15". */
    static String key(Calendar c) {
        return String.format(Locale.US, "%04d-%02d-%02d",
                c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    /** "2026-11-15" → полночь этого дня или null. */
    static Calendar fromKey(String k) {
        if (k == null || !k.matches("\\d{4}-\\d{2}-\\d{2}")) return null;
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(Integer.parseInt(k.substring(0, 4)), Integer.parseInt(k.substring(5, 7)) - 1,
                Integer.parseInt(k.substring(8, 10)));
        return c;
    }

    static Calendar midnight(Calendar c) {
        Calendar m = (Calendar) c.clone();
        m.set(Calendar.HOUR_OF_DAY, 0);
        m.set(Calendar.MINUTE, 0);
        m.set(Calendar.SECOND, 0);
        m.set(Calendar.MILLISECOND, 0);
        return m;
    }

    static Calendar addDays(Calendar c, int n) {
        Calendar d = midnight(c);
        d.add(Calendar.DAY_OF_MONTH, n);
        return d;
    }

    /** Момент «дата + секунды от полуночи» в миллисекундах (с учётом перевода часов). */
    static long at(Calendar day, int seconds) {
        Calendar c = midnight(day);
        c.set(Calendar.HOUR_OF_DAY, seconds / 3600);
        c.set(Calendar.MINUTE, (seconds % 3600) / 60);
        return c.getTimeInMillis();
    }

    /** Сколько календарных дней от a до b. */
    static int daysBetween(Calendar a, Calendar b) {
        long ua = utcDay(a), ub = utcDay(b);
        return (int) Math.round((ub - ua) / 86400000.0);
    }

    private static long utcDay(Calendar c) {
        Calendar u = Calendar.getInstance(java.util.TimeZone.getTimeZone("UTC"));
        u.clear();
        u.set(c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        return u.getTimeInMillis();
    }

    static String plural(int n, String one, String few, String many) {
        int a = Math.abs(n) % 100, b = a % 10;
        if (a > 10 && a < 20) return many;
        if (b == 1) return one;
        if (b > 1 && b < 5) return few;
        return many;
    }

    static boolean isValid(Model.Lesson l) {
        int s = l.startSec(), e = l.endSec();
        return s >= 0 && e >= 0 && s < e;
    }

    private static final Comparator<Model.Lesson> BY_TIME = (a, b) -> {
        int c = Integer.compare(a.startSec(), b.startSec());
        if (c == 0) c = Integer.compare(a.endSec(), b.endSec());
        if (c == 0) c = Integer.compare(a.slot, b.slot);
        return c;
    };

    // ---------------------------------------------------------------- уроки на дату

    static Model.Holiday holidayAt(Model.Data data, String k) {
        for (Model.Holiday h : data.holidays) {
            if (!h.from.isEmpty() && !h.to.isEmpty() && h.from.compareTo(k) <= 0 && k.compareTo(h.to) <= 0) return h;
        }
        return null;
    }

    static boolean hasLessons(Model.Schedule s) {
        if (s == null) return false;
        for (List<Model.Lesson> day : s.days) for (Model.Lesson l : day) if (isValid(l)) return true;
        for (Model.Override o : s.overrides.values()) for (Model.Lesson l : o.added) if (isValid(l)) return true;
        return false;
    }

    /** Уроки одного дня. */
    static final class DayPlan {
        Calendar date;
        String key;
        Model.Holiday holiday;
        boolean off;
        String note = "";
        /** Все уроки (отменённые помечены cancelled) — для показа. */
        final List<Model.Lesson> all = new ArrayList<>();
        /** Только те уроки, что реально будут. */
        final List<Model.Lesson> list = new ArrayList<>();
    }

    /** Уроки на дату с учётом каникул и замен. */
    static DayPlan lessonsFor(Model.Data data, Model.Schedule s, Calendar date) {
        DayPlan p = new DayPlan();
        p.date = midnight(date);
        p.key = key(date);
        p.holiday = holidayAt(data, p.key);
        if (s == null || p.holiday != null) {
            p.off = p.holiday != null;
            return p;
        }
        Model.Override ov = s.overrides.get(p.key);
        if (ov != null) p.note = ov.note;
        Model.BellSet bells = ov != null ? data.bellSet(ov.bells) : null;

        for (Model.Lesson src : s.days[date.get(Calendar.DAY_OF_WEEK) - 1]) {
            Model.Lesson l = src.copy();
            if (bells != null && l.slot >= 0 && l.slot < bells.times.length && bells.times[l.slot] != null) {
                l.start = bells.times[l.slot][0];
                l.end = bells.times[l.slot][1];
            }
            Model.Change c = ov != null ? ov.changes.get(l.slot) : null;
            if (c != null && c.cancel) {
                l.cancelled = true;
            } else if (c != null) {
                if (c.name != null && !c.name.trim().isEmpty()) {
                    l.wasName = l.name;
                    l.name = c.name;
                    l.changed = true;
                }
                if (c.room != null && !c.room.trim().isEmpty()) {
                    l.room = c.room;
                    l.changed = true;
                }
            }
            p.all.add(l);
        }
        if (ov != null) {
            for (int i = 0; i < ov.added.size(); i++) {
                Model.Lesson l = ov.added.get(i).copy();
                l.slot = 100 + i;
                l.added = true;
                p.all.add(l);
            }
            if (ov.dayOff) {
                p.off = true;
                for (Model.Lesson l : p.all) l.cancelled = true;
            }
        }
        for (int i = p.all.size() - 1; i >= 0; i--) if (!isValid(p.all.get(i))) p.all.remove(i);
        Collections.sort(p.all, BY_TIME);
        for (Model.Lesson l : p.all) if (!l.cancelled) p.list.add(l);
        return p;
    }

    // ---------------------------------------------------------------- состояние «сейчас»

    enum Mode { LESSON, BREAK, BEFORE, AFTER, FREE, HOLIDAY, EMPTY }

    static final class State {
        Mode mode = Mode.EMPTY;
        DayPlan day;
        Model.Lesson cur, next, prev;
        Calendar nextDate;
        int daysAhead;
        /** Ближайший звонок (мс) или -1. */
        long target = -1;
        /** Начало текущего отрезка для прогресса (мс) или -1. */
        long from = -1;
        double progress;
        int index;
        int total;
        String holidayName;
        int holidayLeft;
        /** Когда картинка изменится сама: звонок или полночь. */
        long nextChange;
    }

    static State stateAt(Model.Data data, Model.Schedule s, Calendar now) {
        Calendar today = midnight(now);
        double t = now.get(Calendar.HOUR_OF_DAY) * 3600 + now.get(Calendar.MINUTE) * 60
                + now.get(Calendar.SECOND) + now.get(Calendar.MILLISECOND) / 1000.0;
        State st = new State();
        st.day = lessonsFor(data, s, today);
        List<Model.Lesson> L = st.day.list;
        st.total = L.size();

        if (st.day.holiday != null) {
            st.holidayName = st.day.holiday.name.isEmpty() ? "Каникулы" : st.day.holiday.name;
            Calendar end = fromKey(st.day.holiday.to);
            st.holidayLeft = end != null ? daysBetween(today, end) + 1 : 0;
        }
        if (!hasLessons(s)) return finish(st, today);

        // Текущий урок; при пересечении — тот, что кончается раньше (ближайший звонок).
        Model.Lesson cur = null, next = null;
        for (Model.Lesson l : L) {
            if (l.startSec() <= t && t < l.endSec() && (cur == null || l.endSec() < cur.endSec())) cur = l;
            if (next == null && l.startSec() > t) next = l;
        }

        if (cur != null) {
            st.mode = Mode.LESSON;
            st.cur = cur;
            st.next = next;
            st.nextDate = next != null ? today : null;
            st.from = at(today, cur.startSec());
            st.target = at(today, cur.endSec());
            st.index = L.indexOf(cur) + 1;
        } else if (next != null) {
            st.next = next;
            st.nextDate = today;
            st.target = at(today, next.startSec());
            for (Model.Lesson l : L) {
                if (l.endSec() <= t && (st.prev == null || l.endSec() >= st.prev.endSec())) st.prev = l;
            }
            if (st.prev != null) {
                st.mode = Mode.BREAK;
                st.from = at(today, st.prev.endSec());
            } else {
                st.mode = Mode.BEFORE;
            }
            st.index = L.indexOf(next) + 1;
        } else {
            st.mode = st.day.holiday != null ? Mode.HOLIDAY : L.isEmpty() ? Mode.FREE : Mode.AFTER;
            for (int i = 1; i <= SEARCH_DAYS; i++) {
                Calendar d = addDays(today, i);
                DayPlan dp = lessonsFor(data, s, d);
                if (!dp.list.isEmpty()) {
                    st.next = dp.list.get(0);
                    st.nextDate = d;
                    st.daysAhead = i;
                    st.target = at(d, st.next.startSec());
                    break;
                }
            }
        }
        if (st.from >= 0 && st.target > st.from) {
            st.progress = Math.max(0, Math.min(1, (now.getTimeInMillis() - st.from) / (double) (st.target - st.from)));
        }
        return finish(st, today);
    }

    private static State finish(State st, Calendar today) {
        long nextMidnight = addDays(today, 1).getTimeInMillis();
        st.nextChange = st.target >= 0 && st.target < nextMidnight ? st.target : nextMidnight;
        return st;
    }

    // ---------------------------------------------------------------- обратный отсчёт

    static String countdown(Model.Data data, Calendar now) {
        return countdown(data, null, now);
    }

    /**
     * Текст «До выходных 2 дня» / «До конца четверти: 12 дней» или null.
     * s — расписание класса: если в нём есть уроки в субботу, выходной только воскресенье.
     */
    static String countdown(Model.Data data, Model.Schedule s, Calendar now) {
        Model.CountdownSettings c = data.countdown;
        Calendar today = midnight(now);
        if ("weekend".equals(c.mode)) {
            int dow = today.get(Calendar.DAY_OF_WEEK) - 1; // 0 = воскресенье
            if (s != null && hasSaturday(s)) {
                if (dow == 0) return "Выходной!";
                int n = 7 - dow;
                return n == 1 ? "Завтра выходной" : "До выходного " + n + " " + plural(n, "день", "дня", "дней");
            }
            if (dow == 6 || dow == 0) return "Выходные!";
            int n = 6 - dow;
            return n == 1 ? "Завтра выходные" : "До выходных " + n + " " + plural(n, "день", "дня", "дней");
        }
        if ("date".equals(c.mode)) {
            Calendar d = fromKey(c.date);
            if (d == null) return null;
            int n = daysBetween(today, d);
            if (n < 0) return null;
            String label = c.label == null || c.label.trim().isEmpty() ? "До конца четверти" : c.label.trim();
            return n == 0 ? label + ": сегодня!" : label + ": " + n + " " + plural(n, "день", "дня", "дней");
        }
        return null;
    }

    private static boolean hasSaturday(Model.Schedule s) {
        for (Model.Lesson l : s.days[6]) if (isValid(l)) return true;
        return false;
    }

    // ---------------------------------------------------------------- уведомления

    enum EventType { LESSON_SOON, LESSON_END, HOMEWORK }

    /** Одно запланированное уведомление. */
    static final class Event {
        EventType type;
        long time;
        Calendar day;
        Model.Lesson lesson;
        /** Для LESSON_END: следующий урок этого дня или null. */
        Model.Lesson after;
    }

    /**
     * Ближайшее уведомление строго позже afterMillis (или null).
     * Смотрим на 8 дней вперёд — дальше всё равно пересчитаем при следующем срабатывании.
     */
    static Event nextEvent(Model.Data data, Model.Schedule s, long afterMillis) {
        Model.NotifySettings ns = data.notify;
        if (!ns.enabled || s == null) return null;
        Calendar base = Calendar.getInstance();
        base.setTimeInMillis(afterMillis);
        Event best = null;
        int hwSec = sec(ns.homeworkTime);
        for (int i = 0; i <= 8; i++) {
            Calendar d = addDays(base, i);
            if (best != null && d.getTimeInMillis() > best.time) break;
            DayPlan dp = lessonsFor(data, s, d);
            for (int j = 0; j < dp.list.size(); j++) {
                Model.Lesson l = dp.list.get(j);
                long soon = at(d, l.startSec()) - ns.minutesBefore * 60000L;
                best = better(best, afterMillis, EventType.LESSON_SOON, soon, d, l, null);
                if (ns.lessonEnd) {
                    Model.Lesson after = null;
                    for (Model.Lesson x : dp.list) {
                        if (x.startSec() >= l.endSec()) { after = x; break; }
                    }
                    best = better(best, afterMillis, EventType.LESSON_END, at(d, l.endSec()), d, l, after);
                }
            }
            if (ns.homework && hwSec >= 0) {
                best = better(best, afterMillis, EventType.HOMEWORK, at(d, hwSec), d, null, null);
            }
        }
        return best;
    }

    private static Event better(Event best, long after, EventType type, long time, Calendar day,
                                Model.Lesson l, Model.Lesson next) {
        if (time <= after || (best != null && best.time <= time)) return best;
        Event e = new Event();
        e.type = type;
        e.time = time;
        e.day = day;
        e.lesson = l;
        e.after = next;
        return e;
    }

    /**
     * Несделанная домашка к следующему учебному дню после «сегодня»
     * (и к пропущенным дням между ними). Пусто — напоминать не о чем.
     */
    static List<Model.Homework> homeworkDue(Model.Data data, Model.Schedule s, Calendar today) {
        List<Model.Homework> out = new ArrayList<>();
        String from = key(today);
        String to = null;
        for (int i = 1; i <= 30 && to == null; i++) {
            Calendar d = addDays(today, i);
            if (!lessonsFor(data, s, d).list.isEmpty()) to = key(d);
        }
        if (to == null) return out;
        for (Model.Homework h : data.homework) {
            if (!h.done && h.date.compareTo(from) > 0 && h.date.compareTo(to) <= 0) out.add(h);
        }
        return out;
    }

    /** Домашка к конкретному уроку (дата + номер урока) или null. */
    static Model.Homework homeworkFor(Model.Data data, String dateKey, Model.Lesson l) {
        for (Model.Homework h : data.homework) {
            if (h.date.equals(dateKey) && h.slot == l.slot && !h.text.trim().isEmpty()) return h;
        }
        return null;
    }
}
