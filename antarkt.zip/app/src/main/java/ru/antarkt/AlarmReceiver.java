package ru.antarkt;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Срабатывание наших будильников (см. Alarms). */
public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context c, Intent intent) {
        String action = intent.getAction();
        if (Alarms.ACTION_WIDGET.equals(action) || Alarms.ACTION_PROGRESS.equals(action)) {
            AntarktWidget.refresh(c);
        } else if (Alarms.ACTION_NOTIFY.equals(action)) {
            showDue(c);
        }
    }

    /**
     * Показать все уведомления, время которых наступило (их может быть несколько
     * в одну минуту), и поставить будильник на следующее.
     */
    private static void showDue(Context c) {
        Model.Data data = Store.load(c);
        Model.Schedule s = data.schedule("");
        long now = System.currentTimeMillis();
        long from = now - Alarms.STALE_MS;
        ScheduleLogic.Event e;
        int guard = 0;
        long until = now + 30_000L; // будильник мог сработать чуть раньше срока
        while ((e = ScheduleLogic.nextEvent(data, s, from)) != null && e.time <= until && guard++ < 10) {
            Notifier.show(c, data, s, e);
            from = e.time;
        }
        Alarms.scheduleNotifications(c, data, until);
    }
}
