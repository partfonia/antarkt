package ru.antarkt;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.Calendar;
import java.util.List;

/** Показ уведомлений: «Через 5 минут — Алгебра, каб. 214», «Урок закончился», домашка. */
final class Notifier {

    static final String CH_LESSONS = "lessons";
    static final String CH_HOMEWORK = "homework";

    private static final int ID_SOON = 1;
    private static final int ID_END = 2;
    private static final int ID_HOMEWORK = 3;

    private static final String[] DAY_SHORT = {"вс", "пн", "вт", "ср", "чт", "пт", "сб"};

    private Notifier() {
    }

    /** Каналы уведомлений (Android 8+). Их звук и вид можно поменять в настройках телефона. */
    static void createChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm == null) return;
        NotificationChannel lessons = new NotificationChannel(CH_LESSONS, "Уроки",
                NotificationManager.IMPORTANCE_DEFAULT);
        lessons.setDescription("Напоминание перед уроком и о конце урока");
        NotificationChannel hw = new NotificationChannel(CH_HOMEWORK, "Домашка",
                NotificationManager.IMPORTANCE_DEFAULT);
        hw.setDescription("Вечернее напоминание о несделанной домашке");
        nm.createNotificationChannel(lessons);
        nm.createNotificationChannel(hw);
    }

    static void show(Context c, Model.Data data, Model.Schedule s, ScheduleLogic.Event e) {
        switch (e.type) {
            case LESSON_SOON:
                showSoon(c, data, e);
                break;
            case LESSON_END:
                showEnd(c, e);
                break;
            case HOMEWORK:
                showHomework(c, data, s, e);
                break;
        }
    }

    private static void showSoon(Context c, Model.Data data, ScheduleLogic.Event e) {
        Model.Lesson l = e.lesson;
        int min = data.notify.minutesBefore;
        String title = (min <= 0 ? "Начинается " : "Через " + min + " "
                + ScheduleLogic.plural(min, "минуту", "минуты", "минут") + " — ")
                + l.title() + room(l);
        StringBuilder text = new StringBuilder(l.start + "–" + l.end);
        if (l.changed && l.wasName != null) text.append(" · замена вместо ").append(l.wasName);
        Model.Homework hw = ScheduleLogic.homeworkFor(data, ScheduleLogic.key(e.day), l);
        if (hw != null) text.append(hw.done ? " · домашка сделана" : " · домашка: " + hw.text.trim());
        long lessonEnd = ScheduleLogic.at(e.day, l.endSec());
        post(c, ID_SOON, builder(c, CH_LESSONS, title, text.toString(), "")
                .setWhen(ScheduleLogic.at(e.day, l.startSec())), lessonEnd);
    }

    private static void showEnd(Context c, ScheduleLogic.Event e) {
        String text = e.after != null
                ? "Дальше: " + e.after.title() + " в " + e.after.start + room(e.after)
                : "Уроки на сегодня всё";
        post(c, ID_END, builder(c, CH_LESSONS, "Урок закончился", text, ""), 0);
    }

    private static void showHomework(Context c, Model.Data data, Model.Schedule s, ScheduleLogic.Event e) {
        List<Model.Homework> due = ScheduleLogic.homeworkDue(data, s, e.day);
        if (due.isEmpty()) return;
        Calendar first = ScheduleLogic.fromKey(due.get(0).date);
        int days = first != null ? ScheduleLogic.daysBetween(e.day, first) : 1;
        String when = days == 1 || first == null ? "на завтра" : "на " + DAY_SHORT[first.get(Calendar.DAY_OF_WEEK) - 1];
        StringBuilder subjects = new StringBuilder();
        StringBuilder details = new StringBuilder();
        for (Model.Homework h : due) {
            if (subjects.indexOf(h.subject) < 0) {
                if (subjects.length() > 0) subjects.append(", ");
                subjects.append(h.subject);
            }
            if (details.length() > 0) details.append('\n');
            details.append(h.subject).append(": ").append(h.text.trim());
        }
        post(c, ID_HOMEWORK, builder(c, CH_HOMEWORK, "Не сделана домашка " + when, subjects.toString(), "hw")
                .setStyle(new Notification.BigTextStyle().bigText(details)), 0);
    }

    private static String room(Model.Lesson l) {
        String r = l.roomOrEmpty();
        return r.isEmpty() ? "" : ", каб. " + r;
    }

    @SuppressWarnings("deprecation")
    private static Notification.Builder builder(Context c, String channel, String title, String text, String tab) {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, channel)
                : new Notification.Builder(c).setPriority(Notification.PRIORITY_DEFAULT);
        Intent open = new Intent(c, MainActivity.class)
                .putExtra(MainActivity.EXTRA_TAB, tab)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, tab.isEmpty() ? 10 : 11, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return b.setSmallIcon(R.drawable.ic_notify)
                .setColor(0xFF4C8DFF)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setShowWhen(true);
    }

    /** removeAt > 0 — убрать уведомление в этот момент (например, когда урок закончился). */
    private static void post(Context c, int id, Notification.Builder b, long removeAt) {
        createChannels(c);
        if (removeAt > 0 && Build.VERSION.SDK_INT >= 26) {
            long left = removeAt - System.currentTimeMillis();
            if (left > 0) b.setTimeoutAfter(left);
        }
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.notify(id, b.build());
    }
}
