package ru.antarkt;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.TypedValue;
import android.view.View;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/**
 * Виджет на рабочий стол: что сейчас (урок / перемена / уроки закончились / каникулы),
 * таймер до звонка, полоска прогресса и оставшиеся уроки.
 *
 * Таймер — системный Chronometer: он тикает сам, без нашего кода. Мы перерисовываем
 * виджет только когда меняется состояние (по будильнику на ближайший звонок или полночь)
 * и раз в минуту, чтобы двигалась полоска прогресса.
 *
 * Настройки каждого виджета (цвета, размер, класс) лежат в SharedPreferences "w<id>" —
 * их пишет WidgetConfig.
 */
public class AntarktWidget extends AppWidgetProvider {

    private static final int[] LIST_ROWS = {R.id.l0, R.id.l1, R.id.l2, R.id.l3, R.id.l4, R.id.l5, R.id.l6, R.id.l7};
    private static final String[] DAY_SHORT = {"вс", "пн", "вт", "ср", "чт", "пт", "сб"};
    private static final Locale RU = new Locale("ru");

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        refresh(c);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context c, AppWidgetManager m, int id, Bundle options) {
        refresh(c); // виджет растянули/сжали
    }

    @Override
    public void onDeleted(Context c, int[] ids) {
        for (int id : ids) c.deleteSharedPreferences("w" + id);
    }

    @Override
    public void onDisabled(Context c) {
        Alarms.cancelWidget(c); // последний виджет убран — будильники не нужны
    }

    /** Перерисовать все виджеты и поставить будильник на следующее изменение. */
    static void refresh(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, AntarktWidget.class));
        if (ids.length == 0) return;
        Model.Data data = Store.load(c);
        long nextChange = Long.MAX_VALUE;
        boolean needsProgress = false;
        for (int id : ids) {
            ScheduleLogic.State st = draw(c, m, id, data);
            nextChange = Math.min(nextChange, st.nextChange);
            needsProgress |= st.mode == ScheduleLogic.Mode.LESSON || st.mode == ScheduleLogic.Mode.BREAK;
        }
        Alarms.scheduleWidget(c, nextChange, needsProgress);
    }

    // ------------------------------------------------------------------ отрисовка

    /** Настройки одного виджета. Ключи те же, что в прошлой версии. */
    private static final class Look {
        int background, text, dim, accent, listSize;
        float scale;
        boolean showNext, showRooms, showCountdown;
        String scheduleId;

        Look(SharedPreferences w) {
            int alpha = w.getInt("bga", 200);
            background = (alpha << 24) | (w.getInt("bgc", 0x000000) & 0xFFFFFF);
            text = 0xFF000000 | w.getInt("tx", 0xFFFFFF);
            dim = (text & 0xFFFFFF) | 0xA0000000;
            accent = 0xFF000000 | w.getInt("ac", 0x4C8DFF);
            listSize = w.getInt("n", 4);
            scale = w.getInt("sz", 100) / 100f;
            showNext = w.getBoolean("nx", true);
            showRooms = w.getBoolean("rm", false);
            showCountdown = w.getBoolean("cnt", true);
            scheduleId = w.getString("cls", "");
        }
    }

    /** Тексты для виджета, вычисленные из состояния расписания. */
    private static final class Texts {
        String status = "", name = "", meta = "", tinyName = "", nextLine = "", staticTimer = "";
        boolean showTimer, showProgress;
    }

    private static ScheduleLogic.State draw(Context c, AppWidgetManager m, int id, Model.Data data) {
        Look look = new Look(c.getSharedPreferences("w" + id, Context.MODE_PRIVATE));
        Model.Schedule sch = data.schedule(look.scheduleId);
        Calendar now = Calendar.getInstance();
        ScheduleLogic.State st = ScheduleLogic.stateAt(data, sch, now);
        Texts tx = texts(st, look, now);
        String countdown = look.showCountdown ? ScheduleLogic.countdown(data, now) : null;

        // Размер виджета в dp: от него зависит, что поместится.
        Bundle op = m.getAppWidgetOptions(id);
        int height = op.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 110);
        int width = op.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250);
        boolean micro = width < 120;   // узкий: только таймер
        boolean tiny = height < 75;    // одна строка
        boolean mid = height < 115;    // без заголовка
        float k = look.scale * (tiny ? 0.62f : mid ? 0.82f : 1f);

        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
        v.setInt(R.id.bg, "setColorFilter", 0xFF000000 | (look.background & 0xFFFFFF));
        v.setInt(R.id.bg, "setImageAlpha", look.background >>> 24);

        String header = (sch != null ? sch.name : "Антаркт") + " · "
                + new SimpleDateFormat("EE, d MMM", RU).format(now.getTime());
        text(v, R.id.hd, header, look.dim, 12 * k);
        text(v, R.id.st, tx.status, look.accent, 11 * k);
        text(v, R.id.nm, tiny ? tx.tinyName : tx.name, look.text, 20 * k);
        text(v, R.id.mt, tx.meta, look.dim, 13 * k);
        text(v, R.id.ex, countdown == null ? "" : countdown, look.accent, 12 * k);
        visible(v, R.id.hd, !mid && !micro);
        visible(v, R.id.st, !tiny && !micro && !tx.status.isEmpty());
        visible(v, R.id.mt, height >= 105 && !micro && !tx.meta.isEmpty());
        visible(v, R.id.ex, height >= 125 && !micro && countdown != null);

        // Таймер до звонка.
        if (tx.showTimer) {
            long left = st.target - now.getTimeInMillis();
            v.setChronometerCountDown(R.id.cd, true);
            v.setChronometer(R.id.cd, SystemClock.elapsedRealtime() + left, null, true);
            v.setTextColor(R.id.cd, look.text);
            float size = 38 * k;
            if (micro) size = microTimerSize(width, height, look.scale, left);
            v.setTextViewTextSize(R.id.cd, TypedValue.COMPLEX_UNIT_SP, size);
        } else {
            v.setChronometer(R.id.cd, SystemClock.elapsedRealtime(), null, false);
        }
        visible(v, R.id.cd, tx.showTimer);
        text(v, R.id.cds, tx.staticTimer, look.text, (micro ? 14 : 24) * k);
        visible(v, R.id.cds, !tx.showTimer && !tx.staticTimer.isEmpty() && !tiny);

        boolean progress = tx.showProgress && (!micro || height >= 44);
        if (progress) {
            v.setProgressBar(R.id.pb, 1000, (int) (st.progress * 1000), false);
            if (Build.VERSION.SDK_INT >= 31) {
                v.setColorStateList(R.id.pb, "setProgressTintList", ColorStateList.valueOf(look.accent));
            }
        }
        visible(v, R.id.pb, progress);

        // В узком виджете — только таймер по центру.
        boolean solo = micro && tx.showTimer;
        visible(v, R.id.sp1, solo);
        visible(v, R.id.sp2, solo);
        visible(v, R.id.col, !solo);
        if (micro && !tx.showTimer) {
            v.setTextViewTextSize(R.id.nm, TypedValue.COMPLEX_UNIT_SP, Math.max(9f, Math.min(14f, width / 6f)));
        }
        float dp = c.getResources().getDisplayMetrics().density;
        int padH = (int) ((micro || tiny ? 6 : 12) * dp), padV = (int) ((micro || tiny ? 2 : 6) * dp);
        v.setViewPadding(R.id.inner, padH, padV, padH, padV);

        // «Дальше: …» и список оставшихся уроков.
        boolean next = look.showNext && height >= 130 && !micro && !tx.nextLine.isEmpty();
        text(v, R.id.nx, tx.nextLine, look.dim, 13 * k);
        visible(v, R.id.nx, next);
        int capacity = height < 150 || micro ? 0 : Math.min(look.listSize, Math.max(0, (height - 135) / 19));
        drawList(v, st, look, now, capacity, k);

        v.setOnClickPendingIntent(R.id.root, PendingIntent.getActivity(c, 0,
                new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE));
        m.updateAppWidget(id, v);
        return st;
    }

    private static Texts texts(ScheduleLogic.State st, Look look, Calendar now) {
        Texts t = new Texts();
        switch (st.mode) {
            case LESSON:
                t.status = "УРОК " + st.index + " ИЗ " + st.total;
                t.name = st.cur.title();
                t.tinyName = t.name;
                t.meta = times(st.cur, look);
                t.showTimer = true;
                t.showProgress = true;
                if (st.next != null) t.nextLine = "Дальше: " + st.next.title() + " · " + st.next.start;
                break;
            case BREAK:
                t.status = "ПЕРЕМЕНА";
                t.name = st.next.title();
                t.tinyName = "Перемена · " + t.name;
                t.meta = times(st.next, look);
                t.showTimer = true;
                t.showProgress = true;
                break;
            case BEFORE:
                t.status = "ДО НАЧАЛА";
                t.name = st.next.title();
                t.tinyName = t.name;
                t.meta = times(st.next, look);
                t.showTimer = true;
                break;
            case AFTER:
            case FREE:
                t.status = st.mode == ScheduleLogic.Mode.AFTER ? "УРОКИ ЗАКОНЧИЛИСЬ" : "СЕГОДНЯ БЕЗ УРОКОВ";
                if (st.next != null) {
                    t.name = st.next.title();
                    t.tinyName = t.name;
                    t.meta = whenText(st, now) + " в " + st.next.start + room(st.next, look);
                    long left = st.target - now.getTimeInMillis();
                    t.showTimer = left < 24 * 3600_000L;
                    if (!t.showTimer) {
                        t.staticTimer = st.daysAhead + " " + ScheduleLogic.plural(st.daysAhead, "день", "дня", "дней");
                    }
                } else {
                    t.name = "Отдыхаем";
                    t.tinyName = t.name;
                }
                if (!st.day.note.isEmpty()) t.meta = st.day.note;
                break;
            case HOLIDAY:
                t.status = st.holidayName.toUpperCase(RU);
                t.name = "Каникулы, осталось " + st.holidayLeft + " "
                        + ScheduleLogic.plural(st.holidayLeft, "день", "дня", "дней");
                t.tinyName = "Каникулы · " + st.holidayLeft + " дн.";
                if (st.nextDate != null) {
                    t.meta = "Учёба с " + new SimpleDateFormat("EE, d MMM", RU).format(st.nextDate.getTime());
                }
                break;
            case EMPTY:
            default:
                t.status = "НЕТ РАСПИСАНИЯ";
                t.name = "Откройте Антаркт";
                t.tinyName = t.name;
                break;
        }
        return t;
    }

    private static void drawList(RemoteViews v, ScheduleLogic.State st, Look look, Calendar now, int capacity, float k) {
        int row = 0;
        if (st.day != null) {
            int nowSec = now.get(Calendar.HOUR_OF_DAY) * 3600 + now.get(Calendar.MINUTE) * 60 + now.get(Calendar.SECOND);
            List<Model.Lesson> lessons = st.day.list;
            for (Model.Lesson l : lessons) {
                if (row >= capacity || row >= LIST_ROWS.length) break;
                if (l.endSec() <= nowSec) continue; // уже прошли
                String line = l.start + "  " + l.title() + (l.changed ? " · замена" : "")
                        + (look.showRooms && !l.roomOrEmpty().isEmpty() ? " · " + l.roomOrEmpty() : "");
                text(v, LIST_ROWS[row], line, l == st.cur ? look.accent : look.text, 13 * k);
                visible(v, LIST_ROWS[row], true);
                row++;
            }
        }
        for (; row < LIST_ROWS.length; row++) visible(v, LIST_ROWS[row], false);
    }

    // ------------------------------------------------------------------ мелочи

    private static String times(Model.Lesson l, Look look) {
        return l.start + "–" + l.end + room(l, look);
    }

    private static String room(Model.Lesson l, Look look) {
        return look.showRooms && !l.roomOrEmpty().isEmpty() ? " · " + l.roomOrEmpty() : "";
    }

    /** «завтра» / «пн» / «пн, 23 нояб.» для следующего урока. */
    private static String whenText(ScheduleLogic.State st, Calendar now) {
        if (st.daysAhead == 1) return "завтра";
        String day = DAY_SHORT[st.nextDate.get(Calendar.DAY_OF_WEEK) - 1];
        return st.daysAhead < 7 ? day : day + ", " + new SimpleDateFormat("d MMM", RU).format(st.nextDate.getTime());
    }

    /** Размер шрифта таймера для узкого виджета: чтобы цифры влезли по ширине и высоте. */
    private static float microTimerSize(int width, int height, float scale, long leftMs) {
        float perChar = leftMs >= 36_000_000L ? 5.6f : leftMs >= 3_600_000L ? 4.9f : 3.5f;
        return Math.max(9f, Math.min(Math.min(38f * scale, (width - 8) / perChar), (height - 8) / 1.4f));
    }

    private static void text(RemoteViews v, int id, String s, int color, float sp) {
        v.setTextViewText(id, s);
        v.setTextColor(id, color);
        v.setTextViewTextSize(id, TypedValue.COMPLEX_UNIT_SP, sp);
    }

    private static void visible(RemoteViews v, int id, boolean on) {
        v.setViewVisibility(id, on ? View.VISIBLE : View.GONE);
    }
}
