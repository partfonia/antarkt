package ru.antarkt;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;

/**
 * Настройки виджета: открываются, когда виджет ставят на рабочий стол
 * (и при долгом нажатии → «Настроить» на Android 12+).
 * Экран собран кодом, без XML: карточки «Класс», «Цвета», «Фон и размер»,
 * «Быстрые стили», «Показывать» и живой предпросмотр сверху.
 * Сохраняет всё в SharedPreferences "w<id>" (ключи читает AntarktWidget.Look).
 */
public class WidgetConfig extends Activity {

    // Цвета самого экрана настроек (он всегда тёмный).
    private static final int BG = 0xFF0B0B0E, CARD = 0xFF15151A, LINE = 0xFF2A2A31, MUTE = 0xFF8A8A92,
            FIELD = 0xFF1E1E24, ACCENT = 0xFF4C8DFF;
    /** Палитра для фона, текста и акцента виджета. */
    private static final int[] PALETTE = {0x000000, 0x1C1C22, 0x0E1F3D, 0xFFFFFF, 0x4C8DFF, 0x3DD68C,
            0xFF7A59, 0xFFC83D, 0xB07CFF, 0xFF5C8A};
    private static final int KEY_BG = 0, KEY_TEXT = 1, KEY_ACCENT = 2;

    private int widgetId;
    private SharedPreferences prefs;

    // Текущие значения настроек.
    private final int[] colors = new int[3];
    private int alpha, textSize, listSize;
    private boolean showNext, showRooms, showCountdown;
    private String scheduleId = "";

    // Элементы экрана.
    private LinearLayout column, preview;
    private TextView pHeader, pStatus, pName, pTimer;
    private SeekBar alphaBar;
    private final View[][] swatches = new View[3][PALETTE.length];
    private final EditText[] hexFields = new EditText[3];
    private boolean updatingHex;
    private final List<TextView> classChips = new ArrayList<>();
    private final List<String> classIds = new ArrayList<>();
    private int cardIndex;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setResult(RESULT_CANCELED); // если закрыть «назад» — виджет не добавится
        widgetId = getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }
        loadPrefs();

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        ScrollView scroll = new ScrollView(this);
        scroll.setClipToPadding(false);
        scroll.setPadding(dp(18), dp(40), dp(18), dp(110));
        scroll.setVerticalScrollBarEnabled(false);
        column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(column);
        root.addView(scroll);

        column.addView(label("Виджет", 32, 0xFFFFFFFF, true));
        TextView sub = label("Настройте под себя. Предпросмотр меняется сразу", 14, MUTE, false);
        sub.setPadding(0, dp(4), 0, dp(6));
        column.addView(sub);

        buildPreview();
        buildClassCard();

        LinearLayout colorsCard = card("Цвета");
        colorRow(colorsCard, "Фон", KEY_BG);
        colorRow(colorsCard, "Текст", KEY_TEXT);
        colorRow(colorsCard, "Акцент", KEY_ACCENT);

        LinearLayout sizeCard = card("Фон и размер");
        alphaBar = slider(sizeCard, "Прозрачность фона", 255, alpha, p -> (100 - p * 100 / 255) + "%", p -> alpha = p);
        slider(sizeCard, "Размер текста", 100, textSize - 60, p -> (p + 60) + "%", p -> textSize = p + 60);
        slider(sizeCard, "Уроков в списке", 8, listSize, String::valueOf, p -> listSize = p);

        LinearLayout presets = card("Быстрые стили");
        LinearLayout presetRow = horizontalRow(presets);
        chip(presetRow, "Стекло").setOnClickListener(v -> preset(v, 0x000000, 0xFFFFFF, 0x4C8DFF, 90));
        chip(presetRow, "Прозрачный").setOnClickListener(v -> preset(v, -1, -1, -1, 0));
        chip(presetRow, "Тёмный").setOnClickListener(v -> preset(v, 0x1C1C22, 0xFFFFFF, 0x3DD68C, 225));
        chip(presetRow, "Светлый").setOnClickListener(v -> preset(v, 0xFFFFFF, 0x000000, 0x4C8DFF, 235));

        LinearLayout show = card("Показывать");
        toggle(show, "Следующий урок", showNext, on -> showNext = on);
        toggle(show, "Кабинеты", showRooms, on -> showRooms = on);
        toggle(show, "Отсчёт до выходных / четверти", showCountdown, on -> showCountdown = on);
        TextView hint = label("Что считать — выбирается в приложении: Расписание → Счётчик.", 13, MUTE, false);
        hint.setPadding(0, dp(2), 0, 0);
        show.addView(hint);

        Button done = new Button(this);
        done.setText("Готово");
        done.setAllCaps(false);
        done.setTextSize(17);
        done.setTypeface(Typeface.DEFAULT_BOLD);
        done.setTextColor(0xFFFFFFFF);
        done.setBackground(rounded(ACCENT, 28, 0));
        done.setStateListAnimator(null);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, dp(56), Gravity.BOTTOM);
        lp.setMargins(dp(18), 0, dp(18), dp(22));
        root.addView(done, lp);
        done.setOnClickListener(v -> {
            tap(v);
            save();
        });

        setContentView(root);
        updatePreview();
    }

    private void loadPrefs() {
        prefs = getSharedPreferences("w" + widgetId, MODE_PRIVATE);
        colors[KEY_BG] = prefs.getInt("bgc", 0) & 0xFFFFFF;
        colors[KEY_TEXT] = prefs.getInt("tx", 0xFFFFFF) & 0xFFFFFF;
        colors[KEY_ACCENT] = prefs.getInt("ac", 0x4C8DFF) & 0xFFFFFF;
        alpha = prefs.getInt("bga", 200);
        textSize = prefs.getInt("sz", 100);
        listSize = prefs.getInt("n", 4);
        showNext = prefs.getBoolean("nx", true);
        showRooms = prefs.getBoolean("rm", false);
        showCountdown = prefs.getBoolean("cnt", true);
        scheduleId = prefs.getString("cls", "");
    }

    private void save() {
        prefs.edit()
                .putInt("bgc", colors[KEY_BG]).putInt("tx", colors[KEY_TEXT]).putInt("ac", colors[KEY_ACCENT])
                .putInt("bga", alpha).putInt("sz", textSize).putInt("n", listSize)
                .putBoolean("nx", showNext).putBoolean("rm", showRooms).putBoolean("cnt", showCountdown)
                .putString("cls", scheduleId)
                .apply();
        AntarktWidget.refresh(this);
        setResult(RESULT_OK, new Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId));
        finish();
    }

    // ------------------------------------------------------------------ части экрана

    /** Предпросмотр: виджет на «обоях» из градиента. */
    private void buildPreview() {
        LinearLayout card = card(null);
        card.setPadding(dp(10), dp(10), dp(10), dp(10));
        FrameLayout wallpaper = new FrameLayout(this);
        wallpaper.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF22385E, 0xFF0A0F1E, 0xFF1F3B38}));

        preview = new LinearLayout(this);
        preview.setOrientation(LinearLayout.VERTICAL);
        preview.setPadding(dp(14), dp(10), dp(14), dp(10));
        pHeader = label("8Б · пн, 16 нояб.", 11, 0xFFFFFFFF, false);
        preview.addView(pHeader);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        pStatus = label("УРОК 2 ИЗ 7", 10, 0xFFFFFFFF, true);
        pName = label("Алгебра", 17, 0xFFFFFFFF, true);
        texts.addView(pStatus);
        texts.addView(pName);
        pTimer = label("24:18", 30, 0xFFFFFFFF, true);
        row.addView(texts, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(pTimer);
        preview.addView(row);

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER);
        lp.setMargins(dp(14), dp(18), dp(14), dp(18));
        wallpaper.addView(preview, lp);
        card.addView(wallpaper, new LinearLayout.LayoutParams(-1, dp(130)));
    }

    /** Выбор класса: «Из приложения» (какой выбран там) или конкретный. */
    private void buildClassCard() {
        LinearLayout card = card("Класс");
        LinearLayout row = horizontalRow(card);
        List<String> names = new ArrayList<>();
        names.add("Из приложения");
        classIds.add("");
        for (Model.Schedule s : Store.load(this).schedules) {
            names.add(s.name);
            classIds.add(s.id);
        }
        for (int i = 0; i < names.size(); i++) {
            String id = classIds.get(i);
            TextView chip = chip(row, names.get(i));
            classChips.add(chip);
            chip.setOnClickListener(v -> {
                tap(v);
                scheduleId = id;
                markClassChips();
            });
        }
        markClassChips();
    }

    private void markClassChips() {
        for (int i = 0; i < classChips.size(); i++) {
            boolean on = classIds.get(i).equals(scheduleId);
            classChips.get(i).setBackground(rounded(on ? ACCENT : FIELD, 20, on ? ACCENT : LINE));
        }
    }

    /** Строка цветов: кружки палитры + поле для своего HEX-цвета. */
    private void colorRow(LinearLayout card, String title, int key) {
        TextView t = label(title, 14, 0xFFFFFFFF, true);
        t.setPadding(0, dp(key == KEY_BG ? 0 : 14), 0, dp(8));
        card.addView(t);
        LinearLayout row = horizontalRow(card);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(4), dp(4), dp(4), dp(4));
        for (int i = 0; i < PALETTE.length; i++) {
            int color = PALETTE[i];
            View dot = new View(this);
            dot.setContentDescription(String.format("Цвет #%06X", color));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(34), dp(34));
            lp.rightMargin = dp(10);
            row.addView(dot, lp);
            swatches[key][i] = dot;
            dot.setOnClickListener(v -> {
                tap(v);
                setColor(key, color);
            });
        }
        EditText hex = new EditText(this);
        hexFields[key] = hex;
        hex.setText(hex(colors[key]));
        hex.setTextSize(14);
        hex.setTextColor(0xFFFFFFFF);
        hex.setSingleLine(true);
        hex.setBackground(rounded(FIELD, 12, LINE));
        hex.setPadding(dp(12), dp(6), dp(12), dp(6));
        row.addView(hex, new LinearLayout.LayoutParams(dp(96), dp(40)));
        hex.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (updatingHex) return;
                try {
                    colors[key] = Color.parseColor(s.toString().trim()) & 0xFFFFFF;
                    markSwatches(key);
                    updatePreview();
                } catch (IllegalArgumentException ignored) {
                    // цвет ещё не допечатан
                }
            }
        });
        markSwatches(key);
    }

    private void setColor(int key, int color) {
        colors[key] = color & 0xFFFFFF;
        updatingHex = true;
        hexFields[key].setText(hex(colors[key]));
        updatingHex = false;
        markSwatches(key);
        updatePreview();
    }

    private void markSwatches(int key) {
        for (int i = 0; i < PALETTE.length; i++) {
            boolean on = PALETTE[i] == colors[key];
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(0xFF000000 | PALETTE[i]);
            g.setStroke(dp(on ? 3 : 1), on ? 0xFFFFFFFF : LINE);
            swatches[key][i].setBackground(g);
            swatches[key][i].animate().scaleX(on ? 1.15f : 1f).scaleY(on ? 1.15f : 1f).setDuration(160).start();
        }
    }

    private void preset(View v, int bg, int text, int accent, int newAlpha) {
        tap(v);
        if (bg >= 0) setColor(KEY_BG, bg);
        if (text >= 0) setColor(KEY_TEXT, text);
        if (accent >= 0) setColor(KEY_ACCENT, accent);
        alphaBar.setProgress(newAlpha);
    }

    private void updatePreview() {
        preview.setBackground(rounded((alpha << 24) | colors[KEY_BG], 18, 0));
        pHeader.setTextColor(0xA0000000 | colors[KEY_TEXT]);
        pStatus.setTextColor(0xFF000000 | colors[KEY_ACCENT]);
        pName.setTextColor(0xFF000000 | colors[KEY_TEXT]);
        pTimer.setTextColor(0xFF000000 | colors[KEY_TEXT]);
        float k = textSize / 100f;
        pHeader.setTextSize(11 * k);
        pStatus.setTextSize(10 * k);
        pName.setTextSize(17 * k);
        pTimer.setTextSize(30 * k);
    }

    // ------------------------------------------------------------------ строительные блоки

    /** Карточка с заголовком; появляется с небольшой задержкой друг за другом. */
    private LinearLayout card(String title) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(rounded(CARD, 22, LINE));
        c.setPadding(dp(16), dp(14), dp(16), dp(16));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(12);
        column.addView(c, lp);
        if (title != null) {
            TextView t = label(title.toUpperCase(), 11, MUTE, true);
            t.setLetterSpacing(.12f);
            t.setPadding(0, 0, 0, dp(10));
            c.addView(t);
        }
        c.setAlpha(0);
        c.setTranslationY(dp(16));
        c.animate().alpha(1).translationY(0).setStartDelay(cardIndex++ * 50L).setDuration(320)
                .setInterpolator(new DecelerateInterpolator(2f)).start();
        return c;
    }

    private LinearLayout horizontalRow(LinearLayout parent) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(this);
        hs.addView(row);
        parent.addView(hs);
        return row;
    }

    private SeekBar slider(LinearLayout card, String title, int max, int value, IntFunction<String> format, IntConsumer onChange) {
        LinearLayout head = new LinearLayout(this);
        head.setPadding(0, dp(10), 0, 0);
        TextView name = label(title, 14, 0xFFFFFFFF, true);
        TextView val = label(format.apply(value), 14, MUTE, false);
        head.addView(name, new LinearLayout.LayoutParams(0, -2, 1));
        head.addView(val);
        card.addView(head);
        SeekBar s = new SeekBar(this);
        s.setMax(max);
        s.setProgress(value);
        s.setContentDescription(title);
        s.setProgressTintList(ColorStateList.valueOf(ACCENT));
        s.setThumbTintList(ColorStateList.valueOf(0xFFFFFFFF));
        card.addView(s);
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean fromUser) {
                val.setText(format.apply(p));
                onChange.accept(p);
                updatePreview();
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                tap(sb);
            }
        });
        return s;
    }

    private void toggle(LinearLayout card, String title, boolean on, Consumer<Boolean> onChange) {
        Switch s = new Switch(this);
        s.setText(title);
        s.setTextSize(15);
        s.setTextColor(0xFFFFFFFF);
        s.setChecked(on);
        s.setMinHeight(dp(48));
        s.setThumbTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{ACCENT, 0xFFCCCCCC}));
        s.setTrackTintList(new ColorStateList(new int[][]{{android.R.attr.state_checked}, {}},
                new int[]{0x884C8DFF, 0x33FFFFFF}));
        s.setOnCheckedChangeListener((b, v) -> {
            tap(b);
            onChange.accept(v);
        });
        card.addView(s);
    }

    private TextView chip(LinearLayout row, String text) {
        TextView c = label(text, 14, 0xFFFFFFFF, true);
        c.setPadding(dp(16), dp(12), dp(16), dp(12));
        c.setBackground(rounded(FIELD, 22, LINE));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(8);
        row.addView(c, lp);
        return c;
    }

    private TextView label(String text, float sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private GradientDrawable rounded(int color, float radiusDp, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        if (strokeColor != 0) g.setStroke(dp(1), strokeColor);
        return g;
    }

    private int dp(float x) {
        return (int) (x * getResources().getDisplayMetrics().density + .5f);
    }

    private void tap(View v) {
        v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    private static String hex(int color) {
        return String.format("#%06X", color & 0xFFFFFF);
    }
}
