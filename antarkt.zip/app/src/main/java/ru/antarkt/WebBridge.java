package ru.antarkt;

import android.Manifest;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

/**
 * Мост между интерфейсом (JavaScript-объект Android) и телефоном.
 *
 * Методы вызываются из фонового потока WebView, поэтому всё, что трогает экран,
 * выполняется через runOnUiThread.
 */
final class WebBridge {

    private final MainActivity activity;
    private final Context app;

    WebBridge(MainActivity activity) {
        this.activity = activity;
        this.app = activity.getApplicationContext();
    }

    // ------------------------------------------------------------------ данные

    /** Все данные (JSON). */
    @JavascriptInterface
    public String getData() {
        return Store.read(app);
    }

    /** Сохранить все данные и сразу обновить виджет и уведомления. */
    @JavascriptInterface
    public boolean setData(String json) {
        if (!Store.write(app, json)) return false;
        Alarms.refreshAll(app);
        return true;
    }

    /** Расписания по умолчанию (assets/defaults.json). */
    @JavascriptInterface
    public String getDefaults() {
        return Store.defaults(app);
    }

    /** Перенесены ли уже данные из localStorage прошлой версии. */
    @JavascriptInterface
    public boolean isLocalStorageMigrated() {
        return Store.isLocalStorageMigrated(app);
    }

    @JavascriptInterface
    public void setLocalStorageMigrated() {
        Store.setLocalStorageMigrated(app);
    }

    // ------------------------------------------------------------------ тема и экран

    @JavascriptInterface
    public boolean isNight() {
        return activity.isNight();
    }

    /** Цвет системных панелей под тему: color — "#RRGGBB", light — светлая тема. */
    @JavascriptInterface
    public void setSystemBars(String color, boolean light) {
        int c = MainActivity.parseColor(color, light ? 0xFFF4F6FA : 0xFF0A0D14);
        activity.runOnUiThread(() -> activity.setSystemBars(c, light));
    }

    @JavascriptInterface
    public void keepScreenOn(boolean on) {
        activity.runOnUiThread(() -> activity.keepScreenOn(on));
    }

    /** Лёгкий отклик на нажатие (системная тактильная отдача, без разрешений). */
    @JavascriptInterface
    public void haptic() {
        activity.runOnUiThread(activity::haptic);
    }

    /** Вибрация на смене урока/перемены. */
    @JavascriptInterface
    @SuppressWarnings("deprecation")
    public void vibrate(int ms) {
        Vibrator v = (Vibrator) app.getSystemService(Context.VIBRATOR_SERVICE);
        if (v == null || !v.hasVibrator()) return;
        long[] pattern = {0, ms, 120, ms};
        if (Build.VERSION.SDK_INT >= 26) v.vibrate(VibrationEffect.createWaveform(pattern, -1));
        else v.vibrate(pattern, -1);
    }

    @JavascriptInterface
    public String appVersion() {
        try {
            PackageInfo p = app.getPackageManager().getPackageInfo(app.getPackageName(), 0);
            return p.versionName;
        } catch (PackageManager.NameNotFoundException e) {
            return "";
        }
    }

    // ------------------------------------------------------------------ разрешения

    /** Можно ли ставить точные будильники (иначе таймер и уведомления могут опаздывать). */
    @JavascriptInterface
    public boolean canExactAlarms() {
        return Alarms.canExact(app);
    }

    /** Открыть системный экран «Будильники и напоминания» для этого приложения. */
    @JavascriptInterface
    public void openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT < 31) return;
        activity.runOnUiThread(() -> {
            Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + app.getPackageName()));
            try {
                activity.startActivity(i);
            } catch (Exception e) {
                openAppSettings();
            }
        });
    }

    /** Разрешены ли уведомления (Android 13+ спрашивает отдельно). */
    @JavascriptInterface
    public boolean canNotify() {
        if (Build.VERSION.SDK_INT >= 33
                && app.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            return false;
        }
        NotificationManager nm = (NotificationManager) app.getSystemService(Context.NOTIFICATION_SERVICE);
        return nm == null || nm.areNotificationsEnabled();
    }

    /**
     * Попросить разрешение на уведомления. Если система больше не показывает
     * запрос (пользователь дважды отказал или выключил их в настройках) — открываем настройки.
     */
    @JavascriptInterface
    public void requestNotifications() {
        activity.runOnUiThread(() -> {
            boolean granted = Build.VERSION.SDK_INT < 33
                    || activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
            if (granted) {
                openNotificationSettings(); // разрешение есть, но уведомления выключены в системе
                return;
            }
            android.content.SharedPreferences p = app.getSharedPreferences("a", Context.MODE_PRIVATE);
            boolean askedBefore = p.getBoolean("askedNotify", false);
            if (!askedBefore || activity.shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                p.edit().putBoolean("askedNotify", true).apply();
                activity.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        MainActivity.REQ_NOTIFY_PERMISSION);
            } else {
                openNotificationSettings();
            }
        });
    }

    private void openNotificationSettings() {
        Intent i = Build.VERSION.SDK_INT >= 26
                ? new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, app.getPackageName())
                : new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.getPackageName()));
        try {
            activity.startActivity(i);
        } catch (Exception e) {
            openAppSettings();
        }
    }

    private void openAppSettings() {
        activity.startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + app.getPackageName())));
    }

    // ------------------------------------------------------------------ резервная копия

    /** «Поделиться» текстом через системное меню (мессенджеры, заметки, буфер обмена). */
    @JavascriptInterface
    public void shareText(String title, String text) {
        activity.runOnUiThread(() -> {
            Intent send = new Intent(Intent.ACTION_SEND)
                    .setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, text);
            activity.startActivity(Intent.createChooser(send, title));
        });
    }

    /** Сохранить текст в файл: система спросит, куда (Загрузки, Диск и т.п.). */
    @JavascriptInterface
    public void saveFile(String name, String content) {
        activity.runOnUiThread(() -> {
            activity.pendingSave = content;
            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("application/json")
                    .putExtra(Intent.EXTRA_TITLE, name);
            try {
                activity.startActivityForResult(i, MainActivity.REQ_SAVE_FILE);
            } catch (Exception e) {
                activity.js("window.onFileSaved&&onFileSaved(false)");
            }
        });
    }

    /** Выбрать файл резервной копии; текст придёт в window.onFileLoaded(text). */
    @JavascriptInterface
    public void openFile() {
        activity.runOnUiThread(() -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT)
                    .addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("*/*")
                    .putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain", "application/octet-stream"});
            try {
                activity.startActivityForResult(i, MainActivity.REQ_OPEN_FILE);
            } catch (Exception e) {
                activity.js("window.onFileLoaded&&onFileLoaded(null)");
            }
        });
    }
}
