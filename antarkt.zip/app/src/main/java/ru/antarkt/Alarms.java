package ru.antarkt;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;

/**
 * Все будильники приложения:
 *  - WIDGET — точный, на ближайший звонок или полночь: виджет меняет «урок/перемена»;
 *  - PROGRESS — неточный раз в минуту, пока идёт урок/перемена: двигает полоску прогресса;
 *  - NOTIFY — ближайшее уведомление («через 5 минут…», «урок закончился», домашка).
 *
 * Будильники виджета не будят телефон (RTC): пока экран выключен, их всё равно не видно,
 * а при включении экрана пропущенный будильник срабатывает сразу. Уведомления будят (RTC_WAKEUP).
 */
final class Alarms {

    private static final String TAG = "Antarkt";

    static final String ACTION_WIDGET = "ru.antarkt.TICK";
    static final String ACTION_PROGRESS = "ru.antarkt.PROGRESS";
    static final String ACTION_NOTIFY = "ru.antarkt.NOTIFY";

    private static final int REQ_WIDGET = 0;
    private static final int REQ_PROGRESS = 1;
    private static final int REQ_NOTIFY = 2;

    /** Уведомление, опоздавшее больше чем на это время, уже не показываем. */
    static final long STALE_MS = 3 * 60_000L;

    private Alarms() {
    }

    /** Разрешены ли точные будильники (Android 12+ может запретить). */
    static boolean canExact(Context c) {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        return am != null && am.canScheduleExactAlarms();
    }

    /** Обновить всё: виджеты и уведомления. Вызывается при любых изменениях. */
    static void refreshAll(Context c) {
        refreshAll(c, false);
    }

    /** force — перерисовать виджеты полностью (после перезагрузки, смены времени, обновления). */
    static void refreshAll(Context c, boolean force) {
        AntarktWidget.refresh(c, force);
        scheduleNotifications(c, Store.load(c));
    }

    /** Будильник на следующее изменение виджета. */
    static void scheduleWidget(Context c, long when, boolean needsProgress) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent tick = pending(c, REQ_WIDGET, ACTION_WIDGET);
        // +300 мс, чтобы точно оказаться «после» звонка, а не за мгновение до него.
        setExact(c, am, AlarmManager.RTC, when + 300, tick);

        PendingIntent progress = pending(c, REQ_PROGRESS, ACTION_PROGRESS);
        if (needsProgress) {
            am.set(AlarmManager.RTC, System.currentTimeMillis() + 60_000L, progress);
        } else {
            am.cancel(progress);
        }
    }

    static void cancelWidget(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        am.cancel(pending(c, REQ_WIDGET, ACTION_WIDGET));
        am.cancel(pending(c, REQ_PROGRESS, ACTION_PROGRESS));
    }

    /** Будильник на ближайшее уведомление (или отмена, если уведомления выключены). */
    static void scheduleNotifications(Context c, Model.Data data) {
        scheduleNotifications(c, data, System.currentTimeMillis());
    }

    /** То же, но ищем уведомления строго позже afterMillis. */
    static void scheduleNotifications(Context c, Model.Data data, long afterMillis) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = pending(c, REQ_NOTIFY, ACTION_NOTIFY);
        ScheduleLogic.Event e = ScheduleLogic.nextEvent(data, data.schedule(""), afterMillis);
        if (e == null) {
            am.cancel(pi);
            return;
        }
        setExact(c, am, AlarmManager.RTC_WAKEUP, e.time, pi);
    }

    /** Точный будильник, если можно; иначе обычный (может опоздать на несколько минут). */
    private static void setExact(Context c, AlarmManager am, int type, long when, PendingIntent pi) {
        try {
            if (canExact(c)) {
                am.setExactAndAllowWhileIdle(type, when, pi);
            } else {
                am.setAndAllowWhileIdle(type, when, pi);
            }
        } catch (SecurityException e) {
            // Разрешение отобрали между проверкой и вызовом — ставим неточный.
            Log.w(TAG, "Точный будильник запрещён", e);
            am.setAndAllowWhileIdle(type, when, pi);
        }
    }

    private static PendingIntent pending(Context c, int request, String action) {
        Intent i = new Intent(c, AlarmReceiver.class).setAction(action);
        return PendingIntent.getBroadcast(c, request, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
