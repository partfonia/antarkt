package ru.antarkt;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Простые классы данных расписания. Без Android и без JSON — чтобы логику
 * (ScheduleLogic) можно было проверять обычными Java-тестами на компьютере.
 * Из JSON их заполняет JsonModel.
 */
final class Model {

    private Model() {
    }

    /** Один урок. Время хранится строками "08:30", как в JSON. */
    static final class Lesson {
        String name = "";
        String room = "";
        String start = "";
        String end = "";
        /** Номер урока по звонкам (0 — «нулевой»/классный час). */
        int slot;

        // Пометки, которые выставляет ScheduleLogic.lessonsFor() для конкретной даты:
        boolean cancelled;
        boolean changed;
        boolean added;
        String wasName;

        Lesson() {
        }

        Lesson(String name, String room, String start, String end, int slot) {
            this.name = name;
            this.room = room;
            this.start = start;
            this.end = end;
            this.slot = slot;
        }

        Lesson copy() {
            Lesson l = new Lesson(name, room, start, end, slot);
            l.cancelled = cancelled;
            l.changed = changed;
            l.added = added;
            l.wasName = wasName;
            return l;
        }

        int startSec() {
            return ScheduleLogic.sec(start);
        }

        int endSec() {
            return ScheduleLogic.sec(end);
        }

        /** Название для показа: пустое превращается в «Урок». */
        String title() {
            String n = name == null ? "" : name.trim();
            return n.isEmpty() ? "Урок" : n;
        }

        String roomOrEmpty() {
            return room == null ? "" : room.trim();
        }
    }

    /** Изменение одного урока на дату: отмена или замена предмета/кабинета. */
    static final class Change {
        boolean cancel;
        String name;
        String room;
    }

    /** Замены на конкретную дату. */
    static final class Override {
        boolean dayOff;
        String note = "";
        /** id набора звонков (например, сокращённые) или null. */
        String bells;
        final Map<Integer, Change> changes = new HashMap<>();
        final List<Lesson> added = new ArrayList<>();
    }

    /** Расписание класса. days[0] — воскресенье, как в JavaScript. */
    static final class Schedule {
        String id = "";
        String name = "";
        @SuppressWarnings("unchecked")
        final List<Lesson>[] days = new List[7];
        final Map<String, Override> overrides = new HashMap<>();

        Schedule() {
            for (int i = 0; i < 7; i++) days[i] = new ArrayList<>();
        }
    }

    /** Набор звонков: times[k] = {"08:30", "09:10"} или null. */
    static final class BellSet {
        String id = "";
        String name = "";
        String[][] times = new String[0][];
    }

    static final class Holiday {
        String name = "Каникулы";
        String from = "";
        String to = "";
    }

    static final class Homework {
        String date = "";
        int slot;
        String subject = "";
        String text = "";
        boolean done;
    }

    static final class NotifySettings {
        boolean enabled;
        int minutesBefore = 5;
        boolean lessonEnd;
        boolean homework = true;
        String homeworkTime = "19:00";
    }

    static final class CountdownSettings {
        /** off | weekend | date */
        String mode = "off";
        String label = "До конца четверти";
        String date = "";
    }

    /** Всё сохранённое состояние приложения. */
    static final class Data {
        final List<Schedule> schedules = new ArrayList<>();
        String currentId = "";
        final List<BellSet> bells = new ArrayList<>();
        final List<Holiday> holidays = new ArrayList<>();
        final List<Homework> homework = new ArrayList<>();
        NotifySettings notify = new NotifySettings();
        CountdownSettings countdown = new CountdownSettings();

        /** Расписание по id; пустой id или неизвестный — текущее из приложения. */
        Schedule schedule(String id) {
            String want = id == null || id.isEmpty() ? currentId : id;
            for (Schedule s : schedules) if (s.id.equals(want)) return s;
            for (Schedule s : schedules) if (s.id.equals(currentId)) return s;
            return schedules.isEmpty() ? null : schedules.get(0);
        }

        BellSet bellSet(String id) {
            if (id == null) return null;
            for (BellSet b : bells) if (b.id.equals(id)) return b;
            return null;
        }
    }
}
