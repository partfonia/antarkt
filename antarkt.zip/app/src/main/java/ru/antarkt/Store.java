package ru.antarkt;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * Единственное хранилище расписания — SharedPreferences.
 *
 * Интерфейс (WebView) читает и пишет его через WebBridge, виджет и уведомления
 * читают напрямую. Поэтому виджет работает сразу после установки, даже если
 * приложение ещё не открывали, а очистка данных WebView ничего не стирает.
 *
 * Файл "a" и ключ "data" — те же, что у прошлой версии: она уже копировала туда
 * расписание, так что при обновлении поверх старой версии всё подхватится само.
 */
final class Store {

    private static final String TAG = "Antarkt";
    private static final String PREFS = "a";
    private static final String KEY_DATA = "data";
    /** Перенесены ли данные из localStorage старого интерфейса. */
    private static final String KEY_LS_MIGRATED = "lsMigrated";

    private Store() {
    }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** JSON со всеми данными. Если ничего не сохранено — расписания по умолчанию. */
    static synchronized String read(Context c) {
        String s = prefs(c).getString(KEY_DATA, null);
        if (s == null || s.trim().isEmpty()) {
            s = defaults(c);
            prefs(c).edit().putString(KEY_DATA, s).apply();
        }
        return s;
    }

    /** Сохранить JSON. Битые данные не сохраняем, чтобы не потерять рабочие. */
    static synchronized boolean write(Context c, String json) {
        try {
            JSONObject o = new JSONObject(json);
            if (o.optJSONArray("list") == null || o.optJSONArray("list").length() == 0) return false;
        } catch (JSONException e) {
            Log.w(TAG, "Не сохраняю некорректный JSON", e);
            return false;
        }
        prefs(c).edit().putString(KEY_DATA, json).apply();
        return true;
    }

    /** Разобранные данные; при любой ошибке — расписания по умолчанию. */
    static Model.Data load(Context c) {
        try {
            return JsonModel.parse(read(c));
        } catch (JSONException e) {
            Log.w(TAG, "Сохранённые данные не читаются, беру значения по умолчанию", e);
            try {
                return JsonModel.parse(defaults(c));
            } catch (JSONException e2) {
                return new Model.Data();
            }
        }
    }

    static boolean isLocalStorageMigrated(Context c) {
        return prefs(c).getBoolean(KEY_LS_MIGRATED, false);
    }

    static void setLocalStorageMigrated(Context c) {
        prefs(c).edit().putBoolean(KEY_LS_MIGRATED, true).apply();
    }

    /** assets/defaults.json — тот же файл использует и интерфейс. */
    static String defaults(Context c) {
        try (InputStream in = c.getAssets().open("defaults.json")) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return new String(out.toByteArray(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            Log.e(TAG, "Нет assets/defaults.json", e);
            return "{\"v\":4,\"cur\":\"def\",\"list\":[{\"id\":\"def\",\"name\":\"8Б\",\"d\":{}}]}";
        }
    }
}
