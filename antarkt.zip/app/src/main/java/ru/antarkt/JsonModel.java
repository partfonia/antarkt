package ru.antarkt;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;

/**
 * Разбор сохранённого JSON (формат описан в assets/logic.js) в классы Model.
 * Разбор «терпеливый»: недостающие поля получают значения по умолчанию, поэтому
 * читаются и старые данные версии 3 (до этого обновления).
 */
final class JsonModel {

    private JsonModel() {
    }

    static Model.Data parse(String json) throws JSONException {
        JSONObject o = new JSONObject(json);
        Model.Data d = new Model.Data();
        d.currentId = o.optString("cur", "");

        JSONArray list = o.optJSONArray("list");
        if (list != null) {
            for (int i = 0; i < list.length(); i++) {
                JSONObject s = list.optJSONObject(i);
                if (s != null) d.schedules.add(schedule(s));
            }
        }

        JSONArray bells = o.optJSONArray("bells");
        if (bells != null) {
            for (int i = 0; i < bells.length(); i++) {
                JSONObject b = bells.optJSONObject(i);
                if (b != null) d.bells.add(bellSet(b));
            }
        }

        JSONArray hol = o.optJSONArray("hol");
        if (hol != null) {
            for (int i = 0; i < hol.length(); i++) {
                JSONObject h = hol.optJSONObject(i);
                if (h == null) continue;
                Model.Holiday x = new Model.Holiday();
                x.name = h.optString("name", "");
                x.from = h.optString("from", "");
                x.to = h.optString("to", "");
                d.holidays.add(x);
            }
        }

        JSONArray hw = o.optJSONArray("hw");
        if (hw != null) {
            for (int i = 0; i < hw.length(); i++) {
                JSONObject h = hw.optJSONObject(i);
                if (h == null) continue;
                Model.Homework x = new Model.Homework();
                x.date = h.optString("date", "");
                x.slot = h.optInt("k", -1);
                x.subject = h.optString("n", "");
                x.text = h.optString("t", "");
                x.done = h.optBoolean("done", false);
                d.homework.add(x);
            }
        }

        JSONObject n = o.optJSONObject("notif");
        if (n != null) {
            d.notify.enabled = n.optBoolean("on", false);
            d.notify.minutesBefore = Math.max(0, Math.min(60, n.optInt("before", 5)));
            d.notify.lessonEnd = n.optBoolean("end", false);
            d.notify.homework = n.optBoolean("hw", true);
            d.notify.homeworkTime = n.optString("hwTime", "19:00");
        }

        JSONObject c = o.optJSONObject("count");
        if (c != null) {
            d.countdown.mode = c.optString("mode", "off");
            d.countdown.label = c.optString("label", "До конца четверти");
            d.countdown.date = c.optString("date", "");
        }
        return d;
    }

    private static Model.Schedule schedule(JSONObject s) {
        Model.Schedule x = new Model.Schedule();
        x.id = s.optString("id", "");
        x.name = s.optString("name", "");
        // "d" — объект {"0": [...], ..., "6": [...]}; на всякий случай понимаем и массив.
        JSONObject dObj = s.optJSONObject("d");
        JSONArray dArr = s.optJSONArray("d");
        for (int day = 0; day < 7; day++) {
            JSONArray lessons = dObj != null ? dObj.optJSONArray(String.valueOf(day))
                    : dArr != null ? dArr.optJSONArray(day) : null;
            if (lessons == null) continue;
            for (int i = 0; i < lessons.length(); i++) {
                JSONObject l = lessons.optJSONObject(i);
                if (l != null) x.days[day].add(lesson(l, i));
            }
        }

        JSONObject ov = s.optJSONObject("ov");
        if (ov != null) {
            Iterator<String> keys = ov.keys();
            while (keys.hasNext()) {
                String date = keys.next();
                JSONObject v = ov.optJSONObject(date);
                if (v != null) x.overrides.put(date, override(v));
            }
        }
        return x;
    }

    private static Model.Override override(JSONObject v) {
        Model.Override o = new Model.Override();
        o.dayOff = v.optBoolean("off", false);
        o.note = v.optString("note", "");
        o.bells = str(v, "bells", null);
        if (o.bells != null && o.bells.isEmpty()) o.bells = null;

        JSONObject changes = v.optJSONObject("l");
        if (changes != null) {
            Iterator<String> keys = changes.keys();
            while (keys.hasNext()) {
                String k = keys.next();
                JSONObject c = changes.optJSONObject(k);
                if (c == null) continue;
                Model.Change ch = new Model.Change();
                ch.cancel = c.optInt("x", 0) == 1 || c.optBoolean("x", false);
                ch.name = str(c, "n", null);
                ch.room = str(c, "r", null);
                try {
                    o.changes.put(Integer.parseInt(k), ch);
                } catch (NumberFormatException ignored) {
                    // ключ должен быть номером урока; чужие ключи пропускаем
                }
            }
        }
        JSONArray add = v.optJSONArray("add");
        if (add != null) {
            for (int i = 0; i < add.length(); i++) {
                JSONObject l = add.optJSONObject(i);
                if (l != null) o.added.add(lesson(l, 100 + i));
            }
        }
        return o;
    }

    private static Model.Lesson lesson(JSONObject l, int fallbackSlot) {
        Model.Lesson x = new Model.Lesson();
        x.name = str(l, "n", "");
        x.room = str(l, "r", "");
        x.start = str(l, "s", "");
        x.end = str(l, "e", "");
        x.slot = l.isNull("k") ? fallbackSlot : l.optInt("k", fallbackSlot);
        return x;
    }

    /** Строковое поле; отсутствующее или JSON null → fallback (optString вернул бы "null"). */
    private static String str(JSONObject o, String key, String fallback) {
        return o.has(key) && !o.isNull(key) ? o.optString(key, fallback) : fallback;
    }

    private static Model.BellSet bellSet(JSONObject b) {
        Model.BellSet x = new Model.BellSet();
        x.id = b.optString("id", "");
        x.name = b.optString("name", "");
        JSONArray t = b.optJSONArray("t");
        if (t != null) {
            x.times = new String[t.length()][];
            for (int i = 0; i < t.length(); i++) {
                JSONArray pair = t.optJSONArray(i);
                x.times[i] = pair != null && pair.length() == 2
                        ? new String[]{pair.optString(0, ""), pair.optString(1, "")} : null;
            }
        }
        return x;
    }
}
