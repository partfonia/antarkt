package ru.antarkt;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * События системы, после которых нужно заново поставить будильники и перерисовать виджет:
 * перезагрузка телефона (будильники при ней стираются), обновление приложения,
 * перевод часов, смена часового пояса или даты, выдача разрешения на точные будильники.
 *
 * DATE_CHANGED на Android 8+ в манифест не доставляется — поэтому виджет ещё и сам
 * ставит будильник на полночь (ScheduleLogic.State.nextChange).
 */
public class SystemReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context c, Intent intent) {
        Alarms.refreshAll(c);
    }
}
