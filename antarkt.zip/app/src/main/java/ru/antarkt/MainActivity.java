package ru.antarkt;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Главный экран: WebView с assets/index.html. Всё общение с интерфейсом — через
 * WebBridge (объект Android в JavaScript). Обратно в JavaScript отправляем события:
 * onNativeResume(), onNativeTheme(night), onFileLoaded(text), onBack(), openTab(name).
 */
public class MainActivity extends Activity {

    private static final String TAG = "Antarkt";
    static final String EXTRA_TAB = "tab";

    static final int REQ_SAVE_FILE = 1;
    static final int REQ_OPEN_FILE = 2;
    static final int REQ_NOTIFY_PERMISSION = 3;

    private WebView web;
    private boolean pageReady;
    private String pendingTab;
    /** Текст резервной копии, ждущий, пока пользователь выберет, куда сохранить. */
    String pendingSave;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Notifier.createChannels(this);
        boolean night = isNight();
        int bg = night ? 0xFF0A0D14 : 0xFFF4F6FA;
        setSystemBars(bg, !night);

        web = new WebView(this);
        web.setBackgroundColor(bg);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true); // нужен только чтобы прочитать старые данные при переносе
        s.setAllowContentAccess(false);
        s.setTextZoom(100);           // размер шрифта задаёт сам интерфейс
        web.addJavascriptInterface(new WebBridge(this), "Android");
        // Без WebChromeClient не работают даже console.log и диалоги WebView.
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage m) {
                Log.d(TAG, "js: " + m.message() + " @" + m.lineNumber());
                return true;
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pageReady = true;
                if (pendingTab != null) {
                    openTab(pendingTab);
                    pendingTab = null;
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !url.startsWith("file:///android_asset/"); // наружу из приложения не уходим
            }
        });
        pendingTab = getIntent().getStringExtra(EXTRA_TAB);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String tab = intent.getStringExtra(EXTRA_TAB);
        if (tab != null && !tab.isEmpty()) {
            if (pageReady) openTab(tab);
            else pendingTab = tab;
        }
    }

    private void openTab(String tab) {
        if (tab != null && !tab.isEmpty()) js("window.openTab&&openTab(" + JSONObject.quote(tab) + ")");
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Вернулись из настроек (разрешения, будильники) — интерфейс перепроверит подсказки.
        js("window.onNativeResume&&onNativeResume()");
        Alarms.refreshAll(this);
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        js("window.onNativeTheme&&onNativeTheme(" + isNight() + ")");
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        // Сначала даём интерфейсу закрыть открытое окно; если нечего — выходим.
        web.evaluateJavascript("window.onBack?onBack():false", result -> {
            if (!"true".equals(result)) finish();
        });
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }

    // ------------------------------------------------------------------ для WebBridge

    boolean isNight() {
        return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
    }

    /** Цвет строки состояния и навигации под тему интерфейса. */
    @SuppressWarnings("deprecation")
    void setSystemBars(int color, boolean lightTheme) {
        getWindow().setStatusBarColor(color);
        getWindow().setNavigationBarColor(color);
        View decor = getWindow().getDecorView();
        int flags = decor.getSystemUiVisibility();
        flags = lightTheme ? flags | View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR : flags & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= 26) {
            flags = lightTheme ? flags | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                    : flags & ~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        decor.setSystemUiVisibility(flags);
        if (web != null) web.setBackgroundColor(color);
    }

    void keepScreenOn(boolean on) {
        if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    void haptic() {
        web.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);
    }

    /** Выполнить JavaScript в странице (из любого потока). */
    void js(String code) {
        if (web == null) return;
        web.post(() -> web.evaluateJavascript(code, null));
    }

    // ------------------------------------------------------------------ файлы и разрешения

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        Uri uri = result == RESULT_OK && data != null ? data.getData() : null;
        if (request == REQ_SAVE_FILE) {
            String text = pendingSave;
            pendingSave = null;
            if (uri == null || text == null) return;
            try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                if (out == null) throw new java.io.IOException("нет доступа к файлу");
                out.write(text.getBytes(StandardCharsets.UTF_8));
                js("window.onFileSaved&&onFileSaved(true)");
            } catch (Exception e) {
                Log.w(TAG, "Не удалось сохранить файл", e);
                js("window.onFileSaved&&onFileSaved(false)");
            }
        } else if (request == REQ_OPEN_FILE) {
            if (uri == null) return;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new java.io.IOException("нет доступа к файлу");
                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                byte[] b = new byte[8192];
                int n;
                while ((n = in.read(b)) > 0) {
                    buf.write(b, 0, n);
                    if (buf.size() > 5_000_000) throw new java.io.IOException("файл слишком большой");
                }
                String text = new String(buf.toByteArray(), StandardCharsets.UTF_8);
                js("window.onFileLoaded&&onFileLoaded(" + JSONObject.quote(text) + ")");
            } catch (Exception e) {
                Log.w(TAG, "Не удалось прочитать файл", e);
                js("window.onFileLoaded&&onFileLoaded(null)");
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results);
        js("window.onNativeResume&&onNativeResume()");
        Alarms.refreshAll(this);
    }

    static int parseColor(String hex, int fallback) {
        try {
            return Color.parseColor(hex);
        } catch (Exception e) {
            return fallback;
        }
    }
}
