/*
 * Антаркт — логика расписания (без интерфейса).
 *
 * Этот файл подключается в index.html и в тестах (node tests/logic.test.js).
 * Та же логика повторена на Java в ScheduleLogic.java (для виджета и уведомлений),
 * и оба варианта проверяются одинаковыми тестами. Если меняете правила здесь —
 * поменяйте и там.
 *
 * Формат данных (хранится в SharedPreferences через мост Android):
 * {
 *   v: 4, cur: 'def',
 *   list: [{ id, name,
 *            d:  { 0..6: [{ n:'Алгебра', r:'214', s:'08:30', e:'09:10', k:1 }] },  // 0 = воскресенье
 *            ov: { '2026-11-20': { off, note, bells, l: { [k]: {x:1} | {n, r} }, add: [{n,r,s,e}] } } }],
 *   bells:    [{ id, name, t: [[s,e] | null, ...] }],   // индекс в t = номер урока (k)
 *   dayBells: { 0..6: id | null },                    // какие звонки у какого дня недели
 *   hol:   [{ id, name, from:'2026-12-29', to:'2027-01-11' }],
 *   hw:    [{ id, date:'2026-11-19', k, n:'Алгебра', t:'№ 245', done:false }],
 *   notif: { on, before, end, hw, hwTime },
 *   count: { mode:'off'|'weekend'|'date', label, date },
 *   cfg: {...}, theme: 'auto'|'dark'|'light'
 * }
 */
(function (root) {
  'use strict';

  const DAY_MS = 86400000;
  const SEARCH_DAYS = 400; // насколько далеко ищем следующий урок (летние каникулы ~ 3 мес.)

  const pad = (n) => String(n).padStart(2, '0');

  /** "08:30" → секунды от полуночи; NaN, если строка не похожа на время. */
  function sec(s) {
    const m = /^\s*(\d{1,2}):(\d{2})\s*$/.exec(typeof s === 'string' ? s : '');
    if (!m) return NaN;
    const h = +m[1], mi = +m[2];
    return h > 23 || mi > 59 ? NaN : h * 3600 + mi * 60;
  }

  /** Секунды от полуночи → "08:30". */
  function hm(x) {
    x = ((Math.floor(x) % 86400) + 86400) % 86400;
    return pad(Math.floor(x / 3600)) + ':' + pad(Math.floor((x % 3600) / 60));
  }

  /** Дата → "2026-11-15" (по местному времени). */
  function key(d) {
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }

  /** "2026-11-15" → Date (местная полночь) или null. */
  function fromKey(k) {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(k || '');
    return m ? new Date(+m[1], +m[2] - 1, +m[3]) : null;
  }

  const midnight = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate());
  const addDays = (d, n) => new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);

  /** Сколько календарных дней от a до b (без влияния перевода часов). */
  function daysBetween(a, b) {
    const ua = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
    const ub = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
    return Math.round((ub - ua) / DAY_MS);
  }

  /** Момент времени: дата + секунды от полуночи. */
  function at(date, s) {
    return new Date(date.getFullYear(), date.getMonth(), date.getDate(), Math.floor(s / 3600), Math.floor((s % 3600) / 60), 0, 0);
  }

  function plural(n, one, few, many) {
    const a = Math.abs(n) % 100, b = a % 10;
    if (a > 10 && a < 20) return many;
    if (b === 1) return one;
    if (b > 1 && b < 5) return few;
    return many;
  }

  const lessonName = (l) => (l && l.n && String(l.n).trim()) || 'Урок';
  const isValid = (l) => l && sec(l.s) < sec(l.e);
  const byTime = (a, b) => sec(a.s) - sec(b.s) || sec(a.e) - sec(b.e) || a.k - b.k;

  function sched(data) {
    return data.list.find((x) => x.id === data.cur) || data.list[0];
  }

  function bellSet(data, id) {
    return (data.bells || []).find((b) => b.id === id) || null;
  }

  function holidayAt(data, k) {
    return (data.hol || []).find((h) => h.from && h.to && h.from <= k && k <= h.to) || null;
  }

  /** Есть ли в расписании хоть один урок (по дням недели). */
  function hasLessons(sch) {
    if (!sch) return false;
    for (let d = 0; d < 7; d++) if ((sch.d[d] || []).some(isValid)) return true;
    return Object.values(sch.ov || {}).some((o) => (o.add || []).some(isValid));
  }

  /**
   * Уроки на конкретную дату с учётом каникул и замен.
   * all  — все уроки дня (отменённые помечены x:1) — для показа;
   * list — только те, что реально будут.
   */
  function lessonsFor(data, sch, date) {
    const k = key(date);
    const hol = holidayAt(data, k);
    const ov = (sch && sch.ov && sch.ov[k]) || null;
    const res = { date: midnight(date), key: k, hol, ov, off: false, note: (ov && ov.note) || '', all: [], list: [] };
    if (!sch || hol) { res.off = !!hol; return res; }

    const bells = ov && ov.bells ? bellSet(data, ov.bells) : null;
    const all = (sch.d[date.getDay()] || []).map((l, i) => {
      const o = { n: l.n || '', r: l.r || '', s: l.s, e: l.e, k: l.k != null ? +l.k : i };
      const slot = bells && bells.t && bells.t[o.k];
      if (slot) { o.s = slot[0]; o.e = slot[1]; o.rt = 1; }
      const c = ov && ov.l && ov.l[o.k];
      if (c && c.x) o.x = 1;
      else if (c) {
        if (c.n && String(c.n).trim()) { o.was = o.n; o.n = c.n; o.ch = 1; }
        if (c.r != null && String(c.r).trim()) { o.r = c.r; o.ch = 1; }
      }
      return o;
    });
    (ov && ov.add || []).forEach((a, i) => all.push({ n: a.n || '', r: a.r || '', s: a.s, e: a.e, k: 100 + i, add: 1 }));

    if (ov && ov.off) { all.forEach((o) => { o.x = 1; }); res.off = true; }
    res.all = all.filter(isValid).sort(byTime);
    res.list = res.all.filter((l) => !l.x);
    return res;
  }

  /**
   * Что происходит в момент now.
   * mode: lesson | break | before | after | free | holiday | empty
   *   lesson  — идёт урок (cur), отсчёт до его конца;
   *   break   — перемена между prev и next;
   *   before  — уроки сегодня ещё не начались;
   *   after   — сегодня уроки были и закончились;
   *   free    — сегодня уроков нет (выходной или отмена);
   *   holiday — каникулы;
   *   empty   — расписание пустое.
   * target — момент ближайшего звонка (Date) или null, from — начало отрезка для прогресса.
   */
  function stateAt(data, sch, now) {
    const today = midnight(now);
    const t = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds() + now.getMilliseconds() / 1000;
    const day = lessonsFor(data, sch, today);
    const L = day.list;
    const st = { now, day, mode: 'empty', cur: null, next: null, prev: null, nextDate: null, daysAhead: 0,
      target: null, from: null, progress: 0, index: 0, total: L.length, holiday: null };

    if (day.hol) {
      const end = fromKey(day.hol.to);
      st.holiday = { name: day.hol.name || 'Каникулы', left: end ? daysBetween(today, end) + 1 : 0 };
    }
    if (!hasLessons(sch)) return finish(st, today);

    // Текущий урок. Если уроки по ошибке пересекаются — берём тот, что кончается раньше (ближайший звонок).
    const cur = L.filter((l) => sec(l.s) <= t && t < sec(l.e)).sort((a, b) => sec(a.e) - sec(b.e))[0] || null;
    const next = L.find((l) => sec(l.s) > t) || null;

    if (cur) {
      st.mode = 'lesson'; st.cur = cur; st.next = next; st.nextDate = next ? today : null;
      st.from = at(today, sec(cur.s)); st.target = at(today, sec(cur.e));
      st.index = L.indexOf(cur) + 1;
    } else if (next) {
      st.next = next; st.nextDate = today; st.target = at(today, sec(next.s));
      const ended = L.filter((l) => sec(l.e) <= t);
      st.prev = ended.sort((a, b) => sec(a.e) - sec(b.e)).pop() || null;
      if (st.prev) { st.mode = 'break'; st.from = at(today, sec(st.prev.e)); }
      else st.mode = 'before';
      st.index = L.indexOf(next) + 1;
    } else {
      st.mode = day.hol ? 'holiday' : L.length ? 'after' : 'free';
      for (let i = 1; i <= SEARCH_DAYS; i++) {
        const d = addDays(today, i);
        const dd = lessonsFor(data, sch, d);
        if (dd.list.length) {
          st.next = dd.list[0]; st.nextDate = d; st.daysAhead = i;
          st.target = at(d, sec(st.next.s));
          break;
        }
      }
    }
    if (st.from && st.target && st.target > st.from) {
      st.progress = Math.min(1, Math.max(0, (now - st.from) / (st.target - st.from)));
    }
    return finish(st, today);
  }

  function finish(st, today) {
    // Когда что-то изменится само по себе: ближайший звонок или полночь (сменится дата).
    const nextMidnight = addDays(today, 1);
    st.nextChange = st.target && st.target < nextMidnight ? st.target : nextMidnight;
    return st;
  }

  /**
   * Обратный отсчёт до выходных или до даты (для виджета и экрана «Сейчас»).
   * sch — расписание класса: если в нём есть уроки в субботу, выходной только воскресенье.
   */
  function countdown(data, now, sch) {
    const c = data.count || {};
    const today = midnight(now);
    if (c.mode === 'weekend') {
      const dow = today.getDay();
      if (sch && (sch.d[6] || []).some(isValid)) {
        if (dow === 0) return { text: 'Выходной!', days: 0 };
        const n = 7 - dow;
        return { text: n === 1 ? 'Завтра выходной' : 'До выходного ' + n + ' ' + plural(n, 'день', 'дня', 'дней'), days: n };
      }
      if (dow === 6 || dow === 0) return { text: 'Выходные!', days: 0 };
      const n = 6 - dow;
      return { text: n === 1 ? 'Завтра выходные' : 'До выходных ' + n + ' ' + plural(n, 'день', 'дня', 'дней'), days: n };
    }
    if (c.mode === 'date') {
      const d = fromKey(c.date);
      if (!d) return null;
      const n = daysBetween(today, d);
      if (n < 0) return null;
      const label = (c.label || 'До конца четверти').trim();
      return { text: n === 0 ? label + ': сегодня!' : label + ': ' + n + ' ' + plural(n, 'день', 'дня', 'дней'), days: n };
    }
    return null;
  }

  /**
   * Следующий урок с таким же названием после момента (date, fromSec).
   * Нужен для «записать домашку к следующему уроку».
   */
  function nextOccurrence(data, sch, name, date, fromSec) {
    const want = String(name || '').trim().toLowerCase();
    for (let i = 0; i <= 120; i++) {
      const d = addDays(midnight(date), i);
      const l = lessonsFor(data, sch, d).list.find((x) =>
        lessonName(x).toLowerCase() === want && (i > 0 || sec(x.s) > fromSec));
      if (l) return { date: d, key: key(d), lesson: l };
    }
    return null;
  }

  /**
   * Приводит данные любой старой версии (v2/v3 из localStorage) к v4
   * и дополняет недостающие поля значениями из defaults.
   */
  function normalize(data, defaults) {
    const D = JSON.parse(JSON.stringify(defaults));
    if (!data || !Array.isArray(data.list) || !data.list.length) data = JSON.parse(JSON.stringify(D));
    // Данные старой версии (без звонков): номера уроков подбираем по звонкам, которые были тогда.
    if (!Array.isArray(data.bells) || !data.bells.length) data.bells = JSON.parse(JSON.stringify(LEGACY_BELLS));
    if (!data.dayBells || typeof data.dayBells !== 'object') data.dayBells = Object.assign({}, LEGACY_DAY_BELLS);
    if (!Array.isArray(data.hol)) data.hol = [];
    if (!Array.isArray(data.hw)) data.hw = [];
    data.notif = Object.assign({}, D.notif, data.notif || {});
    data.count = Object.assign({}, D.count, data.count || {});
    data.cfg = data.cfg && typeof data.cfg === 'object' ? data.cfg : {};
    if (!['auto', 'dark', 'light'].includes(data.theme)) data.theme = 'auto';

    // Классы, которые появились в обновлении приложения, добавляем один раз.
    // Список seeded помнит, какие уже предлагались, — удалённый класс не вернётся.
    const seeded = new Set(Array.isArray(data.seeded) ? data.seeded : []);
    D.list.forEach((s) => {
      if (seeded.has(s.id)) return;
      if (!data.list.find((x) => x.id === s.id)) data.list.push(JSON.parse(JSON.stringify(s)));
      seeded.add(s.id);
    });
    data.seeded = Array.from(seeded);
    data.list.sort((a, b) => a.name.localeCompare(b.name, 'ru'));

    // Новые номера уроков в звонках по умолчанию (например, 8-й урок) дописываем,
    // не трогая уже настроенное время.
    (D.bells || []).forEach((db) => {
      const mine = data.bells.find((b) => b.id === db.id);
      if (mine && Array.isArray(mine.t) && mine.t.length < db.t.length) mine.t = mine.t.concat(db.t.slice(mine.t.length));
    });

    data.list.forEach((s) => {
      s.id = String(s.id || 's' + Date.now());
      s.name = String(s.name || 'Расписание').slice(0, 24);
      if (!s.d || typeof s.d !== 'object') s.d = {};
      if (!s.ov || typeof s.ov !== 'object') s.ov = {};
      for (let d = 0; d < 7; d++) {
        const L = (Array.isArray(s.d[d]) ? s.d[d] : []).map((l) => ({
          n: String(l.n || ''), r: String(l.r || ''), s: String(l.s || ''), e: String(l.e || ''),
          k: l.k != null && isFinite(l.k) ? +l.k : null,
        }));
        assignSlots(data, d, L);
        s.d[d] = L;
      }
    });
    if (!data.list.find((x) => x.id === data.cur)) data.cur = data.list[0].id;

    // Школа поменяла звонки (новая редакция в defaults.json) — ставим их и переставляем
    // время уроков по номерам. Названия, кабинеты, замены и домашка не меняются.
    if ((data.bellsRev || 0) < (D.bellsRev || 0)) {
      data.bells = D.bells;
      data.dayBells = D.dayBells;
      data.list.forEach((s) => { for (let d = 0; d < 7; d++) if (data.dayBells[d]) retime(data, s, d, data.dayBells[d]); });
      data.bellsRev = D.bellsRev;
    }
    data.v = 4;
    return data;
  }

  /** Звонки, которые были зашиты в прошлой версии приложения (до 16.11.2026). */
  const LEGACY_BELLS = [
    { id: 'bm', name: 'Пн и Чт', t: [['08:00', '08:40'], ['08:45', '09:25'], ['09:35', '10:15'], ['10:25', '11:05'], ['11:15', '11:55'], ['12:05', '12:45'], ['12:50', '13:30'], ['13:35', '14:15']] },
    { id: 'bt', name: 'Обычные', t: [null, ['08:30', '09:10'], ['09:20', '10:00'], ['10:10', '10:50'], ['11:00', '11:40'], ['11:50', '12:30'], ['12:35', '13:15'], ['13:20', '14:00']] },
  ];
  const LEGACY_DAY_BELLS = { 0: null, 1: 'bm', 2: 'bt', 3: 'bt', 4: 'bm', 5: 'bt', 6: null };

  /**
   * У каждого урока должен быть номер k (номер по звонкам). По нему работают
   * замены на дату и «сокращённые звонки». Номер подбираем по времени начала.
   */
  function assignSlots(data, dow, L) {
    const bs = bellSet(data, data.dayBells && data.dayBells[dow]);
    const used = new Set();
    L.forEach((l) => { if (l.k != null && !used.has(l.k)) used.add(l.k); else l.k = null; });
    L.forEach((l) => {
      if (l.k != null) return;
      const i = bs ? bs.t.findIndex((x, j) => x && x[0] === l.s && !used.has(j)) : -1;
      if (i >= 0) l.k = i;
      else { let j = 0; while (used.has(j)) j++; l.k = j; }
      used.add(l.k);
    });
  }

  /** Переставить время уроков дня недели под набор звонков (по номерам уроков). */
  function retime(data, sch, dow, bellsId) {
    const bs = bellSet(data, bellsId);
    if (!bs) return 0;
    let n = 0;
    (sch.d[dow] || []).forEach((l) => {
      const slot = bs.t[l.k];
      if (slot) { l.s = slot[0]; l.e = slot[1]; n++; }
    });
    return n;
  }

  const api = { sec, hm, key, fromKey, midnight, addDays, daysBetween, at, plural, lessonName, isValid,
    sched, bellSet, holidayAt, hasLessons, lessonsFor, stateAt, countdown, nextOccurrence, normalize,
    assignSlots, retime };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.AntLogic = api;
})(typeof window !== 'undefined' ? window : this);
