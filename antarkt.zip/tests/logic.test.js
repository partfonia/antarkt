// Тесты логики расписания: node tests/logic.test.js
// Те же случаи проверяются на Java в tests/java/ScheduleLogicTest.java.
'use strict';
const assert = require('assert');
const path = require('path');
const L = require(path.join(__dirname, '../app/src/main/assets/logic.js'));
const defaults = require(path.join(__dirname, '../app/src/main/assets/defaults.json'));

let passed = 0;
function test(name, fn) {
  try { fn(); passed++; } catch (e) { console.error('✗ ' + name + '\n  ' + e.message); process.exitCode = 1; }
}
const D = (y, m, d, h = 0, mi = 0, s = 0) => new Date(y, m - 1, d, h, mi, s);
const lesson = (n, s, e, k, r = '') => ({ n, r, s, e, k });

// Неделя: Пн 16.11.2026 … Вс 22.11.2026
function fixture() {
  const sch = { id: 'x', name: 'Тест', ov: {}, d: {
    0: [], 6: [],
    1: [lesson('Алгебра', '08:30', '09:10', 1, '214'), lesson('Физика', '09:20', '10:00', 2), lesson('История', '10:10', '10:50', 3)],
    2: [lesson('Химия', '08:30', '09:10', 1)],
    3: [], // пустая среда
    4: [lesson('A', '09:00', '10:00', 1), lesson('B', '09:30', '10:30', 2), lesson('C', '11:00', '11:40', 3)], // пересечение
    5: [lesson('Литература', '08:30', '09:10', 1), lesson('Геометрия', '09:20', '10:00', 2)],
  } };
  const data = L.normalize({ list: [sch], cur: 'x', bellsRev: 99 }, defaults); // без перестановки звонков
  data.bells.push({ id: 'sh', name: 'Сокр', t: [null, ['08:00', '08:30'], ['08:35', '09:05'], ['09:10', '09:40']] });
  return data;
}
const st = (data, d) => L.stateAt(data, L.sched(data), d);

test('урок идёт: отсчёт до конца, прогресс', () => {
  const s = st(fixture(), D(2026, 11, 16, 8, 50));
  assert.strictEqual(s.mode, 'lesson');
  assert.strictEqual(s.cur.n, 'Алгебра');
  assert.strictEqual(s.target.getTime(), D(2026, 11, 16, 9, 10).getTime());
  assert.ok(Math.abs(s.progress - 0.5) < 1e-9);
  assert.strictEqual(s.next.n, 'Физика');
  assert.strictEqual(s.index, 1);
});

test('ровно на звонке конца урока — уже перемена', () => {
  const s = st(fixture(), D(2026, 11, 16, 9, 10));
  assert.strictEqual(s.mode, 'break');
  assert.strictEqual(s.prev.n, 'Алгебра');
  assert.strictEqual(s.next.n, 'Физика');
  assert.strictEqual(s.progress, 0);
});

test('ровно на звонке начала — урок', () => {
  const s = st(fixture(), D(2026, 11, 16, 9, 20));
  assert.strictEqual(s.mode, 'lesson');
  assert.strictEqual(s.cur.n, 'Физика');
});

test('до начала уроков', () => {
  const s = st(fixture(), D(2026, 11, 16, 7, 0));
  assert.strictEqual(s.mode, 'before');
  assert.strictEqual(s.next.n, 'Алгебра');
  assert.strictEqual(s.from, null);
});

test('полночь: 00:00 — новый день, 23:59:59 — следующий урок завтра', () => {
  let s = st(fixture(), D(2026, 11, 16, 0, 0, 0));
  assert.strictEqual(s.mode, 'before');
  assert.strictEqual(s.next.n, 'Алгебра');
  s = st(fixture(), D(2026, 11, 16, 23, 59, 59));
  assert.strictEqual(s.mode, 'after');
  assert.strictEqual(s.next.n, 'Химия');
  assert.strictEqual(s.daysAhead, 1);
  assert.strictEqual(s.nextChange.getTime(), D(2026, 11, 17).getTime()); // обновиться в полночь
});

test('пустой день (среда): free, следующий урок в четверг', () => {
  const s = st(fixture(), D(2026, 11, 18, 12, 0));
  assert.strictEqual(s.mode, 'free');
  assert.strictEqual(s.next.n, 'A');
  assert.strictEqual(L.key(s.nextDate), '2026-11-19');
});

test('пятница после уроков → понедельник через выходные', () => {
  const s = st(fixture(), D(2026, 11, 20, 15, 0));
  assert.strictEqual(s.mode, 'after');
  assert.strictEqual(s.daysAhead, 3);
  assert.strictEqual(s.next.n, 'Алгебра');
  assert.strictEqual(s.target.getTime(), D(2026, 11, 23, 8, 30).getTime());
});

test('суббота → понедельник', () => {
  const s = st(fixture(), D(2026, 11, 21, 10, 0));
  assert.strictEqual(s.mode, 'free');
  assert.strictEqual(s.daysAhead, 2);
});

test('пересекающиеся уроки: ближайший звонок', () => {
  const data = fixture();
  let s = st(data, D(2026, 11, 19, 9, 45)); // A 9:00–10:00 и B 9:30–10:30
  assert.strictEqual(s.mode, 'lesson');
  assert.strictEqual(s.cur.n, 'A');
  assert.strictEqual(s.target.getTime(), D(2026, 11, 19, 10, 0).getTime());
  s = st(data, D(2026, 11, 19, 10, 15)); // A закончился, B идёт
  assert.strictEqual(s.cur.n, 'B');
  s = st(data, D(2026, 11, 19, 10, 45)); // перемена после B
  assert.strictEqual(s.mode, 'break');
  assert.strictEqual(s.prev.n, 'B');
  assert.strictEqual(s.next.n, 'C');
});

test('пустое расписание', () => {
  const data = L.normalize({ list: [{ id: 'e', name: 'E', d: {} }], cur: 'e' }, defaults);
  const s = st(data, D(2026, 11, 16, 10, 0));
  assert.strictEqual(s.mode, 'empty');
  assert.strictEqual(s.target, null);
});

test('некорректные уроки (конец раньше начала, пустое время) игнорируются', () => {
  const data = fixture();
  L.sched(data).d[2].push(lesson('Сломанный', '12:00', '11:00', 5), lesson('Пусто', '', '', 6));
  const day = L.lessonsFor(data, L.sched(data), D(2026, 11, 17));
  assert.deepStrictEqual(day.list.map((l) => l.n), ['Химия']);
});

test('каникулы: holiday, осталось N дней, следующий урок после', () => {
  const data = fixture();
  data.hol.push({ id: 'h', name: 'Осенние', from: '2026-11-16', to: '2026-11-22' });
  const s = st(data, D(2026, 11, 18, 9, 0));
  assert.strictEqual(s.mode, 'holiday');
  assert.strictEqual(s.holiday.left, 5); // 18,19,20,21,22
  assert.strictEqual(L.key(s.nextDate), '2026-11-23');
  assert.strictEqual(st(data, D(2026, 11, 22, 23, 0)).holiday.left, 1);
});

test('замены: отмена урока и замена предмета на дату', () => {
  const data = fixture();
  L.sched(data).ov['2026-11-16'] = { l: { 1: { x: 1 }, 2: { n: 'Информатика', r: '301' } } };
  const day = L.lessonsFor(data, L.sched(data), D(2026, 11, 16));
  assert.deepStrictEqual(day.list.map((l) => l.n), ['Информатика', 'История']);
  assert.strictEqual(day.all.length, 3);
  assert.strictEqual(day.list[0].was, 'Физика');
  const s = st(data, D(2026, 11, 16, 8, 0));
  assert.strictEqual(s.mode, 'before');
  assert.strictEqual(s.next.n, 'Информатика');
  // основное расписание не изменилось
  assert.strictEqual(L.sched(data).d[1][0].n, 'Алгебра');
  // через неделю — обычный понедельник
  assert.strictEqual(L.lessonsFor(data, L.sched(data), D(2026, 11, 23)).list[0].n, 'Алгебра');
});

test('отмена всего дня и дополнительный урок', () => {
  const data = fixture();
  L.sched(data).ov['2026-11-17'] = { off: true };
  L.sched(data).ov['2026-11-18'] = { add: [{ n: 'Консультация', r: '', s: '14:00', e: '14:40' }] };
  let s = st(data, D(2026, 11, 17, 7, 0));
  assert.strictEqual(s.mode, 'free');
  assert.strictEqual(s.next.n, 'Консультация');
  s = st(data, D(2026, 11, 18, 14, 10));
  assert.strictEqual(s.mode, 'lesson');
});

test('сокращённые звонки на дату', () => {
  const data = fixture();
  L.sched(data).ov['2026-11-16'] = { bells: 'sh' };
  const day = L.lessonsFor(data, L.sched(data), D(2026, 11, 16));
  assert.deepStrictEqual(day.list.map((l) => l.s + '-' + l.e), ['08:00-08:30', '08:35-09:05', '09:10-09:40']);
});

test('обратный отсчёт до выходных и до даты', () => {
  const data = fixture();
  data.count = { mode: 'weekend' };
  assert.strictEqual(L.countdown(data, D(2026, 11, 16)).text, 'До выходных 5 дней');
  assert.strictEqual(L.countdown(data, D(2026, 11, 19)).text, 'До выходных 2 дня');
  assert.strictEqual(L.countdown(data, D(2026, 11, 20)).text, 'Завтра выходные');
  assert.strictEqual(L.countdown(data, D(2026, 11, 22)).text, 'Выходные!');
  data.count = { mode: 'date', label: 'До конца четверти', date: '2026-12-26' };
  assert.strictEqual(L.countdown(data, D(2026, 11, 15)).text, 'До конца четверти: 41 день');
  assert.strictEqual(L.countdown(data, D(2026, 12, 27)), null);
});

test('следующий урок предмета (для домашки)', () => {
  const data = fixture();
  const o = L.nextOccurrence(data, L.sched(data), 'алгебра', D(2026, 11, 16), L.sec('08:50'));
  assert.strictEqual(o.key, '2026-11-23');
});

test('normalize: старые данные v3 — номер урока по старым звонкам, время по новым', () => {
  const old = { cur: 'def', v: 3, list: [{ id: 'def', name: '8Б', d: { 2: [{ n: 'Физика', r: '214', s: '09:20', e: '10:00' }, { n: 'Своё', s: '15:00', e: '15:40' }] } }] };
  const d = L.normalize(old, defaults);
  assert.strictEqual(d.v, 4);
  const tue = d.list[0].d[2];
  assert.strictEqual(tue[0].k, 2);            // по старым звонкам вторника 09:20 — 2-й урок
  assert.strictEqual(tue[0].s + '-' + tue[0].e, '09:35-10:15'); // 2-й урок по новым звонкам Пн–Пт
  assert.strictEqual(tue[0].r, '214');        // кабинет на месте
  assert.strictEqual(tue[1].k, 0);            // не нашёлся — первый свободный номер (0 → 08:00–08:40)
  assert.strictEqual(d.dayBells[2], 'bm');
  assert.strictEqual(d.dayBells[6], 'sat');
  assert.ok(Array.isArray(d.hw) && Array.isArray(d.hol));
});

test('новые звонки 2026–2027: применяются один раз к данным со старыми звонками', () => {
  const v4old = { v: 4, cur: 'def', bells: JSON.parse(JSON.stringify(defaults.bells)).map((b) => b.id === 'bm' ? b : b), dayBells: { 1: 'bm', 2: 'bt' },
    list: [{ id: 'def', name: '8Б', ov: {}, d: { 2: [{ n: 'Русский язык', r: '', s: '08:30', e: '09:10', k: 1 }] } }] };
  const d = L.normalize(v4old, defaults);
  assert.strictEqual(d.list[0].d[2][0].s, '08:45');
  assert.strictEqual(d.bellsRev, 2);
  // свои правки после обновления больше не перетираются
  d.list[0].d[2][0].s = '08:50';
  assert.strictEqual(L.normalize(d, defaults).list[0].d[2][0].s, '08:50');
});

test('суббота: звонки без нулевого урока', () => {
  const d = L.normalize(null, defaults);
  const sat = L.bellSet(d, d.dayBells[6]);
  assert.strictEqual(sat.t[0], null);
  assert.deepStrictEqual(sat.t[1], ['08:30', '09:10']);
  assert.deepStrictEqual(sat.t[7], ['13:05', '13:45']);
});

test('defaults: вторник 8Б по новым звонкам', () => {
  const d = L.normalize(null, defaults);
  const day = L.lessonsFor(d, L.sched(d), D(2026, 11, 17));
  assert.strictEqual(day.list[0].s + '-' + day.list[0].e, '08:45-09:25');
  assert.strictEqual(day.list[day.list.length - 1].e, '14:15');
});

test('defaults: 8Б в понедельник — 8 уроков с 08:00', () => {
  const d = L.normalize(null, defaults);
  const day = L.lessonsFor(d, L.sched(d), D(2026, 11, 16));
  assert.strictEqual(day.list.length, 8);
  assert.strictEqual(day.list[0].s, '08:00');
});

console.log(passed + ' тестов логики пройдено' + (process.exitCode ? ', есть ошибки' : ''));
