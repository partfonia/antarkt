package ru.antarkt;

import java.util.Calendar;
import java.util.List;

/**
 * Тесты ScheduleLogic без Android и без JUnit — запускаются в GitHub Actions:
 *   javac -d build app/src/main/java/ru/antarkt/{Model,ScheduleLogic}.java tests/java/ScheduleLogicTest.java
 *   java -cp build ru.antarkt.ScheduleLogicTest
 * Случаи те же, что в tests/logic.test.js (JavaScript-версия логики).
 */
public final class ScheduleLogicTest {

    private static int passed, failed;

    public static void main(String[] args) {
        run("урок идёт: отсчёт до конца, прогресс", () -> {
            ScheduleLogic.State s = state(fixture(), at(2026, 11, 16, 8, 50, 0));
            eq(ScheduleLogic.Mode.LESSON, s.mode);
            eq("Алгебра", s.cur.name);
            eq(at(2026, 11, 16, 9, 10, 0).getTimeInMillis(), s.target);
            check(Math.abs(s.progress - 0.5) < 1e-9, "progress " + s.progress);
            eq("Физика", s.next.name);
            eq(1, s.index);
        });
        run("ровно на звонке конца урока — уже перемена", () -> {
            ScheduleLogic.State s = state(fixture(), at(2026, 11, 16, 9, 10, 0));
            eq(ScheduleLogic.Mode.BREAK, s.mode);
            eq("Алгебра", s.prev.name);
            eq("Физика", s.next.name);
            check(s.progress == 0, "progress");
        });
        run("ровно на звонке начала — урок", () -> {
            ScheduleLogic.State s = state(fixture(), at(2026, 11, 16, 9, 20, 0));
            eq(ScheduleLogic.Mode.LESSON, s.mode);
            eq("Физика", s.cur.name);
        });
        run("до начала уроков", () -> {
            ScheduleLogic.State s = state(fixture(), at(2026, 11, 16, 7, 0, 0));
            eq(ScheduleLogic.Mode.BEFORE, s.mode);
            eq("Алгебра", s.next.name);
            eq(-1L, s.from);
        });
        run("полночь", () -> {
            ScheduleLogic.State s = state(fixture(), at(2026, 11, 16, 0, 0, 0));
            eq(ScheduleLogic.Mode.BEFORE, s.mode);
            s = state(fixture(), at(2026, 11, 16, 23, 59, 59));
            eq(ScheduleLogic.Mode.AFTER, s.mode);
            eq("Химия", s.next.name);
            eq(1, s.daysAhead);
            eq(at(2026, 11, 17, 0, 0, 0).getTimeInMillis(), s.nextChange);
        });
        run("пустой день (среда)", () -> {
            ScheduleLogic.State s = state(fixture(), at(2026, 11, 18, 12, 0, 0));
            eq(ScheduleLogic.Mode.FREE, s.mode);
            eq("A", s.next.name);
            eq("2026-11-19", ScheduleLogic.key(s.nextDate));
        });
        run("пятница после уроков → понедельник", () -> {
            ScheduleLogic.State s = state(fixture(), at(2026, 11, 20, 15, 0, 0));
            eq(ScheduleLogic.Mode.AFTER, s.mode);
            eq(3, s.daysAhead);
            eq(at(2026, 11, 23, 8, 30, 0).getTimeInMillis(), s.target);
        });
        run("суббота → понедельник", () -> {
            ScheduleLogic.State s = state(fixture(), at(2026, 11, 21, 10, 0, 0));
            eq(ScheduleLogic.Mode.FREE, s.mode);
            eq(2, s.daysAhead);
        });
        run("пересекающиеся уроки", () -> {
            Model.Data d = fixture();
            ScheduleLogic.State s = state(d, at(2026, 11, 19, 9, 45, 0));
            eq("A", s.cur.name);
            eq(at(2026, 11, 19, 10, 0, 0).getTimeInMillis(), s.target);
            eq("B", state(d, at(2026, 11, 19, 10, 15, 0)).cur.name);
            s = state(d, at(2026, 11, 19, 10, 45, 0));
            eq(ScheduleLogic.Mode.BREAK, s.mode);
            eq("B", s.prev.name);
            eq("C", s.next.name);
        });
        run("пустое расписание", () -> {
            Model.Data d = new Model.Data();
            Model.Schedule e = new Model.Schedule();
            e.id = "e";
            d.schedules.add(e);
            d.currentId = "e";
            ScheduleLogic.State s = state(d, at(2026, 11, 16, 10, 0, 0));
            eq(ScheduleLogic.Mode.EMPTY, s.mode);
            eq(-1L, s.target);
        });
        run("некорректные уроки игнорируются", () -> {
            Model.Data d = fixture();
            d.schedule("").days[2].add(new Model.Lesson("Сломанный", "", "12:00", "11:00", 5));
            d.schedule("").days[2].add(new Model.Lesson("Пусто", "", "", "", 6));
            eq(1, ScheduleLogic.lessonsFor(d, d.schedule(""), at(2026, 11, 17, 0, 0, 0)).list.size());
        });
        run("каникулы", () -> {
            Model.Data d = fixture();
            Model.Holiday h = new Model.Holiday();
            h.name = "Осенние";
            h.from = "2026-11-16";
            h.to = "2026-11-22";
            d.holidays.add(h);
            ScheduleLogic.State s = state(d, at(2026, 11, 18, 9, 0, 0));
            eq(ScheduleLogic.Mode.HOLIDAY, s.mode);
            eq(5, s.holidayLeft);
            eq("2026-11-23", ScheduleLogic.key(s.nextDate));
            eq(1, state(d, at(2026, 11, 22, 23, 0, 0)).holidayLeft);
        });
        run("замены: отмена и замена предмета", () -> {
            Model.Data d = fixture();
            Model.Override ov = new Model.Override();
            Model.Change x = new Model.Change();
            x.cancel = true;
            Model.Change r = new Model.Change();
            r.name = "Информатика";
            r.room = "301";
            ov.changes.put(1, x);
            ov.changes.put(2, r);
            d.schedule("").overrides.put("2026-11-16", ov);
            ScheduleLogic.DayPlan p = ScheduleLogic.lessonsFor(d, d.schedule(""), at(2026, 11, 16, 0, 0, 0));
            eq(2, p.list.size());
            eq("Информатика", p.list.get(0).name);
            eq("Физика", p.list.get(0).wasName);
            eq(3, p.all.size());
            eq("Алгебра", d.schedule("").days[1].get(0).name);
            eq("Информатика", state(d, at(2026, 11, 16, 8, 0, 0)).next.name);
        });
        run("отмена дня и дополнительный урок", () -> {
            Model.Data d = fixture();
            Model.Override off = new Model.Override();
            off.dayOff = true;
            d.schedule("").overrides.put("2026-11-17", off);
            Model.Override add = new Model.Override();
            add.added.add(new Model.Lesson("Консультация", "", "14:00", "14:40", 0));
            d.schedule("").overrides.put("2026-11-18", add);
            ScheduleLogic.State s = state(d, at(2026, 11, 17, 7, 0, 0));
            eq(ScheduleLogic.Mode.FREE, s.mode);
            eq("Консультация", s.next.name);
            eq(ScheduleLogic.Mode.LESSON, state(d, at(2026, 11, 18, 14, 10, 0)).mode);
        });
        run("сокращённые звонки на дату", () -> {
            Model.Data d = fixture();
            Model.Override ov = new Model.Override();
            ov.bells = "sh";
            d.schedule("").overrides.put("2026-11-16", ov);
            List<Model.Lesson> l = ScheduleLogic.lessonsFor(d, d.schedule(""), at(2026, 11, 16, 0, 0, 0)).list;
            eq("08:00-08:30", l.get(0).start + "-" + l.get(0).end);
            eq("09:10-09:40", l.get(2).start + "-" + l.get(2).end);
        });
        run("обратный отсчёт", () -> {
            Model.Data d = fixture();
            d.countdown.mode = "weekend";
            eq("До выходных 5 дней", ScheduleLogic.countdown(d, at(2026, 11, 16, 0, 0, 0)));
            eq("До выходных 2 дня", ScheduleLogic.countdown(d, at(2026, 11, 19, 0, 0, 0)));
            eq("Завтра выходные", ScheduleLogic.countdown(d, at(2026, 11, 20, 0, 0, 0)));
            eq("Выходные!", ScheduleLogic.countdown(d, at(2026, 11, 22, 0, 0, 0)));
            d.countdown.mode = "date";
            d.countdown.label = "До конца четверти";
            d.countdown.date = "2026-12-26";
            eq("До конца четверти: 41 день", ScheduleLogic.countdown(d, at(2026, 11, 15, 0, 0, 0)));
            eq(null, ScheduleLogic.countdown(d, at(2026, 12, 27, 0, 0, 0)));
        });
        run("уведомления: за 5 минут, конец урока, домашка вечером", () -> {
            Model.Data d = fixture();
            d.notify.enabled = true;
            d.notify.minutesBefore = 5;
            d.notify.lessonEnd = true;
            d.notify.homework = true;
            d.notify.homeworkTime = "19:00";
            long t = at(2026, 11, 16, 7, 0, 0).getTimeInMillis();
            ScheduleLogic.Event e = ScheduleLogic.nextEvent(d, d.schedule(""), t);
            eq(ScheduleLogic.EventType.LESSON_SOON, e.type);
            eq(at(2026, 11, 16, 8, 25, 0).getTimeInMillis(), e.time);
            e = ScheduleLogic.nextEvent(d, d.schedule(""), e.time);
            eq(ScheduleLogic.EventType.LESSON_END, e.type);
            eq("Физика", e.after.name);
            e = ScheduleLogic.nextEvent(d, d.schedule(""), at(2026, 11, 16, 11, 0, 0).getTimeInMillis());
            eq(ScheduleLogic.EventType.HOMEWORK, e.type);
            // суббота: уроков нет, ближайшее — домашка в 19:00, потом урок в понедельник
            d.notify.homework = false;
            e = ScheduleLogic.nextEvent(d, d.schedule(""), at(2026, 11, 21, 12, 0, 0).getTimeInMillis());
            eq(at(2026, 11, 23, 8, 25, 0).getTimeInMillis(), e.time);
        });
        run("домашка к следующему учебному дню", () -> {
            Model.Data d = fixture();
            d.homework.add(hw("2026-11-23", false));
            d.homework.add(hw("2026-11-23", true));
            d.homework.add(hw("2026-11-24", false));
            eq(1, ScheduleLogic.homeworkDue(d, d.schedule(""), at(2026, 11, 20, 0, 0, 0)).size());
        });

        System.out.println(passed + " Java-тестов логики пройдено" + (failed > 0 ? ", ошибок: " + failed : ""));
        if (failed > 0) System.exit(1);
    }

    // ------------------------------------------------------------------ вспомогательное

    /** Та же неделя, что и в JS-тесте: Пн 16.11.2026 … Вс 22.11.2026. */
    static Model.Data fixture() {
        Model.Data d = new Model.Data();
        Model.Schedule s = new Model.Schedule();
        s.id = "x";
        s.days[1].add(new Model.Lesson("Алгебра", "214", "08:30", "09:10", 1));
        s.days[1].add(new Model.Lesson("Физика", "", "09:20", "10:00", 2));
        s.days[1].add(new Model.Lesson("История", "", "10:10", "10:50", 3));
        s.days[2].add(new Model.Lesson("Химия", "", "08:30", "09:10", 1));
        s.days[4].add(new Model.Lesson("A", "", "09:00", "10:00", 1));
        s.days[4].add(new Model.Lesson("B", "", "09:30", "10:30", 2));
        s.days[4].add(new Model.Lesson("C", "", "11:00", "11:40", 3));
        s.days[5].add(new Model.Lesson("Литература", "", "08:30", "09:10", 1));
        s.days[5].add(new Model.Lesson("Геометрия", "", "09:20", "10:00", 2));
        d.schedules.add(s);
        d.currentId = "x";
        Model.BellSet sh = new Model.BellSet();
        sh.id = "sh";
        sh.times = new String[][]{null, {"08:00", "08:30"}, {"08:35", "09:05"}, {"09:10", "09:40"}};
        d.bells.add(sh);
        return d;
    }

    static Model.Homework hw(String date, boolean done) {
        Model.Homework h = new Model.Homework();
        h.date = date;
        h.subject = "Алгебра";
        h.text = "№1";
        h.done = done;
        return h;
    }

    static ScheduleLogic.State state(Model.Data d, Calendar now) {
        return ScheduleLogic.stateAt(d, d.schedule(""), now);
    }

    static Calendar at(int y, int mo, int d, int h, int mi, int s) {
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(y, mo - 1, d, h, mi, s);
        return c;
    }

    interface Body {
        void run();
    }

    static void run(String name, Body b) {
        try {
            b.run();
            passed++;
        } catch (Throwable e) {
            failed++;
            System.err.println("✗ " + name + ": " + e);
        }
    }

    static void check(boolean ok, String what) {
        if (!ok) throw new AssertionError(what);
    }

    static void eq(Object want, Object got) {
        if (want == null ? got != null : !want.equals(got)) {
            throw new AssertionError("ожидалось <" + want + ">, получено <" + got + ">");
        }
    }
}
