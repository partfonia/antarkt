# Антаркт

Личное приложение-расписание для 8Б: таймер до звонка, виджет на рабочий стол,
домашка, замены, каникулы и напоминания. Не публикуется — APK собирает GitHub Actions
и ставится на один телефон.

## Как устроено

| Где | Что |
| --- | --- |
| `app/src/main/assets/index.html` | Весь интерфейс (WebView): экраны «Сейчас», «Расписание», «Домашка», настройки |
| `app/src/main/assets/logic.js` | Логика расписания: что идёт сейчас, замены, каникулы, отсчёты |
| `app/src/main/assets/defaults.json` | Расписания 8А–8Г и звонки по умолчанию |
| `ScheduleLogic.java` | Та же логика на Java — для виджета и уведомлений |
| `Store.java` | Единственное хранилище: SharedPreferences (WebView работает с ним через `WebBridge`) |
| `AntarktWidget.java`, `WidgetConfig.java` | Виджет и экран его настройки |
| `Alarms.java`, `AlarmReceiver.java`, `SystemReceiver.java`, `Notifier.java` | Будильники, перезагрузка/смена времени, уведомления |
| `tests/` | Тесты логики на JS и Java (запускаются при каждой сборке) |

Тесты локально:

```sh
node tests/logic.test.js
javac -encoding UTF-8 -d build/t app/src/main/java/ru/antarkt/Model.java \
  app/src/main/java/ru/antarkt/ScheduleLogic.java tests/java/ScheduleLogicTest.java
java -cp build/t ru.antarkt.ScheduleLogicTest
```

## Ключ подписи (один раз)

Все версии должны быть подписаны **одним и тем же** ключом — тогда новая ставится
поверх старой и расписание не теряется.

1. Создайте ключ (нужна Java; `keytool` входит в неё). Пароль придумайте один и тот же
   для хранилища и для ключа:

   ```sh
   keytool -genkeypair -v -keystore antarkt.jks -alias antarkt \
     -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Antarkt"
   ```

2. Переведите файл в текст:
   - Linux: `base64 -w0 antarkt.jks > antarkt.txt`
   - macOS: `base64 -i antarkt.jks -o antarkt.txt`
   - Windows (PowerShell): `[Convert]::ToBase64String([IO.File]::ReadAllBytes("antarkt.jks")) | Set-Content antarkt.txt`

3. В репозитории на GitHub: **Settings → Secrets and variables → Actions → New repository secret**.
   Добавьте четыре секрета:

   | Имя | Значение |
   | --- | --- |
   | `KEYSTORE_BASE64` | всё содержимое `antarkt.txt` |
   | `KEYSTORE_PASSWORD` | пароль |
   | `KEY_ALIAS` | `antarkt` |
   | `KEY_PASSWORD` | тот же пароль |

4. **Сохраните `antarkt.jks` и пароль** в надёжном месте (не в репозиторий). Потеряете ключ —
   следующую версию придётся ставить с удалением старой.

## Сборка и установка

Каждый push запускает **Actions → Build APK**. Готовый файл — в артефакте
`Antarkt-2.0.<номер сборки>`. Номер версии растёт сам.

Локально (нужен Android SDK): `gradle assembleRelease`. Без переменных с ключом APK
подписывается отладочным ключом — годится для проверки, но не для обновления телефона.

**Первая установка этой версии:** прошлые APK подписывались случайным отладочным ключом,
поэтому поверх них новая не встанет — старую придётся удалить один раз. До удаления
перепишите или сфотографируйте свои изменения в расписании (или в старой версии нажмите
«Поделиться» и сохраните текст — новая версия примет его через «⋯ → Импорт из текста»).
Дальше все обновления ставятся поверх.

## Виджет

Долгое нажатие на рабочем столе → Виджеты → Антаркт. Откроются настройки (цвета, класс,
что показывать). Поменять их потом: долгое нажатие на виджете → «Настроить» (Android 12+)
или переставить виджет. Приложение открывать не обязательно — виджет сразу видит расписание.
